//
//  ViewController.m
//  04-Modal
//
//  Created by xiaomage on 15/9/10.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

#import "OneViewController.h"



@interface ViewController ()

@property (nonatomic, strong) UIViewController *vc;

@end

@implementation ViewController
- (IBAction)modal:(id)sender {
    
    UIViewController *vc = [[OneViewController alloc] init];
//    _vc = vc;
//    // 自己写一个Modal
//    // 默认系统的modal => 分析Modal
//    // 把新控制器的view添加到窗口上,而且有从下往上钻的动画
//    
//    // 1.获取获取窗口
//    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
//    [keyWindow addSubview:vc.view];
//    
//    vc.view.transform = CGAffineTransformMakeTranslation(0, self.view.bounds.size.height);
//    
//    // 2.动画
//    [UIView animateWithDuration:0.25 animations:^{
//        vc.view.transform = CGAffineTransformIdentity;
//    } completion:^(BOOL finished) {
//        [self.view removeFromSuperview];
//    }];
    
    // 1.modal出来的控制器的view添加到窗口上,唯一不确定,modal出的控制器需不需要被强引用.
    
    // 跳转到下一个控制器
    [self presentViewController:vc  animated:YES completion:^{
        NSLog(@"%@",self.presentedViewController);
    }];
    
    // 1.只要一个控制器的view显示出来,那么这个控制器就一定不能被销毁.
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
