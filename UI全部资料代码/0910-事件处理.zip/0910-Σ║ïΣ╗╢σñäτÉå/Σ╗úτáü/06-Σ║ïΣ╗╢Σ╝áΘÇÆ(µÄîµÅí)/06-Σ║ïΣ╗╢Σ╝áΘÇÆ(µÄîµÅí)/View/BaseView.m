//
//  BaseView.m
//  06-事件传递(掌握)
//
//  Created by xiaomage on 15/9/10.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "BaseView.h"

@implementation BaseView

// __func__:获取当前方法在哪个类里面调用
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%@--touchesBegan",[self class]);
}

@end
