//
//  XMGTableViewController.h
//  12-抽屉效果
//
//  Created by xiaomage on 15/9/10.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMGTableViewController : UITableViewController

@end
