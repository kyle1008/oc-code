//
//  RedView.m
//  05-View的拖拽
//
//  Created by xiaomage on 15/9/10.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "RedView.h"

@implementation RedView
// 为什么要重写touches,因为我想要监听view的触摸事件

// 当手指开始触摸view的做事情
// NSSet:集合,数组,字典,NSSet无序
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
//{
// // touches:UITouch
//    
//    NSLog(@"%@", touches);
//}


// 当手指在view上移动的时候调用

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    // 让当前控件随着手指移动而移动
    
    // 获取UITouch
    UITouch *touch = [touches anyObject];
    
    // 获取当前点
    CGPoint curP = [touch locationInView:self];
    
    // 获取上一个点
    CGPoint preP = [touch previousLocationInView:self];
    
    // 计算手指x轴偏移量
    CGFloat offsetX = curP.x - preP.x;
    
    // 计算手指x轴偏移量
    CGFloat offsetY = curP.y - preP.y;
    
    // 修改控件的形变
    self.transform = CGAffineTransformTranslate(self.transform, offsetX, offsetY);
}
//
//// 当手指离开当前view的时候调用
//- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
//{
//    NSLog(@"%s",__func__);
//}

// 当触摸事件被打断的时候调用(打电话)
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    
}
@end
