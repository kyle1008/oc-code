//
//  DrawView.m
//  图形上下文状态栈
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//

/*
 
    1.创建一个DrawView,绑定View
      
    2.想要在View上面画一个十字架
     获取上下文
     CGContextRef ctx = UIGraphicsGetCurrentContext();
     //拼接路径
     UIBezierPath *path = [UIBezierPath bezierPath];
     [path moveToPoint:CGPointMake(10, 150)];
     [path addLineToPoint:CGPointMake(290, 150)];
     重新设置起点
     [path moveToPoint:CGPointMake(150, 10)];
     [path addLineToPoint:CGPointMake(150, 290)];
     添加路径到上下文
     CGContextAddPath(ctx, path.CGPath);
     渲染图层
     CGContextStrokePath(ctx);
 
    如果我想把第一根横着的线,设置红色,线宽等于10,怎么做?
    要设置上下文状态,必须要在渲染之前设置
     设置上下文状态
     CGContextSetLineWidth(ctx, 10);
     [[UIColor redColor]set];
    运行发现, 设置一个, 两个都发生也变化.
    为什么两个都变成了一样?
    因为这两个线用的是同一个上下文
 
    PPT演示.
    图形上下文中有两个地方,一个是存放绘图信息, 一个存放绘图状态.
    把上下文渲染到View上时, 它会先绘图信息渲染到View上, 然后再从绘图状态中设置每一个状态
    它用使用的是同一个上下文.
 
 
    解决办法,是再创建一个路径,设置它的上下文状态,覆盖以后的上下文状态
     path = [UIBezierPath bezierPath];
     [path moveToPoint:CGPointMake(150, 10)];
     [path addLineToPoint:CGPointMake(150, 290)];
     
     [[UIColor blackColor] set];
     CGContextSetLineWidth(ctx, 1);
     
     CGContextAddPath(ctx, path.CGPath);
     CGContextStrokePath(ctx);
    
    保证一条线对应一个上下文
 
    重新覆盖上下文状态中的内容,做一次还原
    用这种办法的弊端:还原比较麻烦,现在只修改了两种状态,万一以后修改20种状态,是不是发写20个.
 
    这个时候,可以用一个保存图层上下文状态的栈,一开始把原始的状态保存一份到栈里面,
 
    在修改状态之前就保存一份.
 
     保存上下文状态
     CGContextSaveGState(ctx);
    从上下文状态栈里面取出保存的状态,替换掉当前的状态.
     CGContextRestoreGState(ctx);
 
 */


#import "DrawView.h"

@implementation DrawView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    
    //获取上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    //拼接路径
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    [path moveToPoint:CGPointMake(10, 150)];
    [path addLineToPoint:CGPointMake(290, 150)];
//    //重新设置起点
//    [path moveToPoint:CGPointMake(150, 10)];
//    [path addLineToPoint:CGPointMake(150, 290)];
    
    //添加路径到上下文
    CGContextAddPath(ctx, path.CGPath);
    //保存上下文状态
    CGContextSaveGState(ctx);
    //设置上下文状态
    CGContextSetLineWidth(ctx, 10);
    [[UIColor redColor]set];
    //渲染图层
    CGContextStrokePath(ctx);
    
    
    path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(150, 10)];
    [path addLineToPoint:CGPointMake(150, 290)];
    
//    [[UIColor blackColor] set];
//    CGContextSetLineWidth(ctx, 1);
//
    CGContextRestoreGState(ctx);
    CGContextAddPath(ctx, path.CGPath);
    CGContextStrokePath(ctx);

    
    
    
    
}


@end
