//
//  drawView.m
//  11-上下文的矩阵操作
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//
/*
    1.什么是矩阵操作?
        我们之前学的形变,就是因为改变了它的矩阵,才改变了一些形变.
        那我们的图形上下文也是可以做一些形变的.
      要绘制一个椭圆
    绘制了一个椭圆位置尺寸(-100, -50, 200, 100);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
     UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(-100, -50, 200, 100)];
     CGContextAddPath(ctx, path.CGPath);
     [[UIColor redColor] set];
     CGContextFillPath(ctx);
    
    运行,只有4分之一的椭圆.
 
    想要让它完全显示 ,想要移到出来
    第一种方法改它的,x,y值,
    还有其它方式:可以对上下文做一些形变,让它移出来.
    平移上下文
     CGContextTranslateCTM(ctx,100,50);
 
    注意:矩阵操作必须要在添加路径到上下文之前进行形变.
 
    旋转上下文
     旋转90度
     CGContextRotateCTM(ctx, M_PI_2);
     在开发当中,矩阵操作用的最多的就是旋转操作,因为一些位置,x和y的位置不好确定.
 
     缩放,宽高缩放0.5
     CGContextScaleCTM(ctx, 0.5, 0.5);
 */



#import "drawView.h"

@implementation drawView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(-100, -50, 200, 100)];
    CGContextTranslateCTM(ctx,100,50);
    //旋转90度
    CGContextRotateCTM(ctx, M_PI_2);
    
    //缩放,宽高缩放0.5
    CGContextScaleCTM(ctx, 0.5, 0.5);
    
    CGContextAddPath(ctx, path.CGPath);
    [[UIColor redColor] set];
    CGContextFillPath(ctx);
    
}


@end
