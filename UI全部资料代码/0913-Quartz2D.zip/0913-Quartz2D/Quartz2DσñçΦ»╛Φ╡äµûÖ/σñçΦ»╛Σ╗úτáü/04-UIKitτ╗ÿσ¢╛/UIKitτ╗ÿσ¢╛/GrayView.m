//
//  GrayView.m
//  UIKit绘图
//
//  Created by Gavin on 15/7/28.
//  Copyright © 2015年 Gavin. All rights reserved.
//

/*
    1.画文字
      首先要有文字
      现在UiView也可以显示文字 ,把一个文字画到UIView就好了.
 
     Attributes:给文字添加一些属性,富文本
     字典:描术文字的属性
     [str drawAtPoint:CGPointZero withAttributes:nil];
 
    如果在AwakeFromNib里写能不能写出来?
    验证:
     -(void)awakeFromNib{
         NSString *str = @"小码哥";
        [str drawAtPoint:CGPointZero withAttributes:nil];
     }
    2.结论:画不了来,为什么画不出来?
    原因:想要把一个东西画到View上面,必须得有上下文 ,上下文只有在DrawRect方法中才能拿
        [str drawAtPoint:CGPointZero withAttributes:nil];
        它的底层也是同样也是按着步骤来的
        第一步:获取上下文
        第二步:拼接路径
        第三步:把路径添加到上下文
        第四步:渲染上下文到View
        
    得出,不管有没有上下文,只要在View上面画东西,都得要在DrawRect方法中去写,
 
    3.添加富文本
     NSMutableDictionary *dict = [NSMutableDictionary dictionary];
     字体
     dict[NSFontAttributeName] = [UIFont systemFontOfSize:50];
     颜色
     dict[NSForegroundColorAttributeName] = [UIColor redColor];
     设置边框颜色
     dict[NSStrokeColorAttributeName] = [UIColor redColor];
     dict[NSStrokeWidthAttributeName] = @1;
     阴影
     NSShadow *shadow = [[NSShadow alloc] init];
     shadow.shadowOffset = CGSizeMake(10, 10);
     shadow.shadowColor = [UIColor greenColor];
     shadow.shadowBlurRadius = 3;
     dict[NSShadowAttributeName] = shadow;
 
    这个字典描述文字的属性,颜色,字体大小
    它是通过字典的key和Value来描述.
    怎么样知道Key和Value;
 
    它的key在UIKit框架里面,第一个文件NSStringAttring.h
    
 
     [str drawAtPoint:CGPointZero withAttributes:dict];
     [str drawInRect:rect withAttributes:dict];
     两个方法的区别
    drawAtPoint:不能够自动换行
    drawInRect:能够自动换行
    代码验证
     
 
    4.画图片
        4.1 倒入素材
        4.2 在DrawRect加载图片  UIImage *image = [UIImage imageNamed:@"黄人"];
            绘制图片: [image drawAtPoint:CGPointZero];
            发现黄人只能看见几根毛
            原因:绘制出来的图形跟图片尺寸一样大.
 
        4.3 [image drawInRect:rect];使用这个方法能让整图片限制到自己上面.
        4.4 图片平铺
            UIImage *image = [UIImage imageNamed:@"001"];
            [image drawAsPatternInRect:rect];
 
    5. 用UIKit快速的画一个矩形
         快速的用矩形去填充一个区域
         [[UIColor redColor] set];
         UIRectFill(rect);
 
    6. 用UIKit裁剪一个区域
        只要超出裁剪区域部分,都会被裁剪掉
        UIRectClip(CGRectMake(0, 0, 50, 50));
        
        这个方法必须要设置好裁剪区域,才能有裁剪
 
        验证,把它放到最后面.
        没有裁剪效果
 
 */

#import "GrayView.h"
@implementation GrayView

//
//-(void)awakeFromNib{
//    NSString *str = @"小码哥";
//    
//    //Attributes:给文字添加一些属性,富文本
//    //字典:描术文字的属性
//    [str drawAtPoint:CGPointZero withAttributes:nil];
//}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
//    [[UIColor redColor] set];
//    UIRectFill(rect);
    
    
    
    UIRectClip(CGRectMake(0, 0, 50, 50));
    [self drawImage];
    
    
    

}


- (void)drawImage{
    UIImage *image = [UIImage imageNamed:@"001"];
    //    [image drawAtPoint:CGPointZero];
    [image drawInRect:self.bounds];
    
    [image drawAsPatternInRect:self.bounds];
}




- (void)drawText{
    
    NSString *str = @"小码哥";
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    //字体
    dict[NSFontAttributeName] = [UIFont systemFontOfSize:50];
    //颜色
    dict[NSForegroundColorAttributeName] = [UIColor redColor];
    
    //设置边框颜色
    dict[NSStrokeColorAttributeName] = [UIColor redColor];
    dict[NSStrokeWidthAttributeName] = @1;
    
    NSShadow *shadow = [[NSShadow alloc] init];
    shadow.shadowOffset = CGSizeMake(10, 10);
    shadow.shadowColor = [UIColor greenColor];
    shadow.shadowBlurRadius = 3;
    dict[NSShadowAttributeName] = shadow;
    
    //Attributes:给文字添加一些属性,富文本
    //字典:描术文字的属性
    [str drawAtPoint:CGPointZero withAttributes:dict];
    [str drawInRect:self.bounds withAttributes:dict];
    
    
    
    
    
}



@end
