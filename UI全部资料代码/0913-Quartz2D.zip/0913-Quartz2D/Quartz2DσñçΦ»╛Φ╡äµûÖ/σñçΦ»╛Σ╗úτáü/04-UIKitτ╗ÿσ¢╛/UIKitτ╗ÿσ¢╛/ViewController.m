//
//  ViewController.m
//  UIKit绘图
//
//  Created by Gavin on 15/7/28.
//  Copyright © 2015年 Gavin. All rights reserved.
//

/*
    1.说明:
    我们可以用UIKit封装的一些方法帮我们绘制一些东西,
    可以用它画文字 ,画图片
    新建工程,只要一想到画东西,必须要拿到上下文,想要到上到上下文,必要在DrawRect方法里才能拿,
            必须要重写这个方法 重写这个方法,必须要自定义view
    2.搭建界面,自定义View,
 
 
 */

#import "ViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
