//
//  SnowView.m
//  09-定时器,雪花
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//
/*
 
    1.画图片
        导入图片,加载图片
        把图片绘制到左上角
        UIImage *image = [UIImage imageNamed:@"雪花"];
        [image drawAtPoint:CGPointZero];
        运行,左上角已经绘制了一张图片
 
    2. 想让雪花时刻的往下面移动,
     定义一个_snowY,记录它的Y值.
     让Y值不停的++
     static CGFloat _snowY = 0;
     UIImage *image = [UIImage imageNamed:@"雪花"];
     [image drawAtPoint:CGPointMake(0, _snowY)];
     _snowY += 10;
 
      怎么样让它往下面走?
      每隔一段时间,重新绘制一下,Y值++,它就往下面走了
      每隔一段时间,所以要弄一个定时器
      这个定时器只需要加载一次.所以在-awakeFromNib里面写.
      awakeFromNib只会调用一次
      添加定时期,每隔0.1秒调用一次setNeedsDisplay
 
     -(void)awakeFromNib{
       [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(setNeedsDisplay) userInfo:nil repeats:YES];
     }

    运行发现有点卡顿的效果,还有一个超过屏幕之后不出来了,
    更改时间为0.01
     超过屏幕的高度,把它的Y值设为0
     if(_snowY > rect.size.height){
     _snowY = 0;
     }
 
    是不是用NSTimer也能完成这个效果,
    注意在绘图中,一般不使用NSTimer.会使用另外一个,专门用来绘图的一个定时器
 
     屏幕每次刷新的时候就会调用,通常屏幕每秒刷新60次,
     也就讲这个方法每秒执行60次
     CADisplayLink *link = [CADisplayLink displayLinkWithTarget:self selector:@selector(setNeedsDisplay)];
 
    现在仅仅是创建一个定时器,想要使用它, 必须把它加入到一个RunLoop里面去
    加到主运行循环,到一个默认的一个模式当中
    只要添加到主运行循环, 跟模式没有关系
    [link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
 
 
    为什么要在绘图的时候要用CADisplayLink?
    
    首先要了解setNeedsDisplay
    setNeedsDisplay:底层会调用drawRect进行重绘
    注意:调用setNeedsDisplay,并不会马上触发drawRect方法
         它仅仅是给当前这个View设置一个重新绘制的标志.等一下次屏幕刷新的时候才会调用drawRect
 
   CADisplayLink:屏幕每次刷新的时候就会调用,两个在时间上没有间隔,
 
 
 
 
 
 
 */



#import "SnowView.h"

@implementation SnowView


static CGFloat _snowY = 0;


-(void)awakeFromNib{
//    [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(setNeedsDisplay) userInfo:nil repeats:YES];
    
    
    //屏幕每次刷新的时候就会调用,通常屏幕每秒刷新60次,
    //也就讲这个方法每秒执行60次
    CADisplayLink *link = [CADisplayLink displayLinkWithTarget:self selector:@selector(setNeedsDisplay)];
    //RunLoop它也是一秒循环60次
    [link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
    
}



// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    if(_snowY > rect.size.height){
        _snowY = 0;
    }
    
    UIImage *image = [UIImage imageNamed:@"雪花"];
    [image drawAtPoint:CGPointMake(0, _snowY)];
    _snowY += 10;
    
}

@end
