//
//  ViewController.m
//  09-定时器,雪花
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//
/*
 
    1.演示雪花效果
      雪花就是一张图片,可以用UIImageView,也可以自己绘制一个.
      采取方法, 在屏幕中画一个雪花
      把整个屏幕改为黑色.雪花是白色的.
      要在控制器中画东西,必须要自定义View
      新建一个SnowView,绑定SnowView
 
    2.在drawRect方法中开始绘制雪花
 
 */



#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
