//
//  ViewController.m
//  下载进度条
//
//  Created by Gavin on 15/7/28.
//  Copyright © 2015年 Gavin. All rights reserved.
//

/*
 
   1. 演示示例程序
      说明要在上面画东西,要自定义View
 
   2. 搭建界面
      界面上有一个View,一个Label,一个SlideView
      Label居中显示,滑块取值范围0到1
      自定义ProgressView,绑定View
 
 
      要监听滑块的点击,改变文字的状态,把Label进来
      监听滑块的点击
      设置按钮的文字:
    
 
     .2f:表示保留两们小数
     %%:加一个%会报警告,因为%在stringWithFormat里面有特殊含义,它是一个占位符,所以要转义, 两个%%相当于一个%
     sender.value * 100:刚好是1的时候,显示
      _labelView.text = [NSString stringWithFormat:@"%.2f%%",sender.value * 100];
 
  3. 画圆孤
     分析圆孤从哪个位置开始画?
     从最上面,按顺时针画,所以,它的起始角度是-90度.结束角度也是-90度
     在ProgressView中的drawRect方法中去画,进入ProgressView
 
 
 
 
 
 
 
 */


#import "ViewController.h"
#import "ProgressView.h"
@interface ViewController ()

@property (weak, nonatomic) IBOutlet ProgressView *progressView;
@property (weak, nonatomic) IBOutlet UILabel *labelView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)slideChange:(UISlider *)sender {
    
    
    _labelView.text = [NSString stringWithFormat:@"%.2f%%",sender.value * 100];
    _progressView.progress = sender.value;
    
    NSLog(@"%f",sender.value);
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
