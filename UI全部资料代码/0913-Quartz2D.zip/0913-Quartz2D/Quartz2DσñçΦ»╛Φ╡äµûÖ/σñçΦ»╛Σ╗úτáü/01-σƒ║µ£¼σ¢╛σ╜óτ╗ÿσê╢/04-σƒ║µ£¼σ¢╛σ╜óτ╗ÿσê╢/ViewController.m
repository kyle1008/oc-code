//
//  ViewController.m
//  04-基本图形绘制
//
//  Created by Gavin on 15/7/28.
//  Copyright © 2015年 Gavin. All rights reserved.
//

/*
 
 1.想要画东西必须得有一个画板
    在控制器的上面拖一个UIView,当作是一个画板.
    想要画东西,第一步要自定义View
    原因:要重写它的DrawRect方法,所以要自定义View 起名:lineView,绑定LineView
 2. 进入LineView里面的DrawRect方法
    
    2.1 说明drawRect:
        作用:就是用来绘图用的
        什么时候调用:当控件第一次显示的时候调用, 这个方法只会调用一次
        验证:ViewDidLoad中打印一次,
            在LineView的drawRect方法中打印一次
            在ViewWillAppear中打印一次
            在ViewDidAppear中打印一次
        运行打印顺序:ViewDidLoad
                   ViewWillAppear
                   drawRect
                   ViewDidAppear
        参数:Rect 是什么?
            打印: NSLog(@"%@",NSStringFromCGRect(rect));
            结论:当前View的Bounds
 */


#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
