//
//  LineView.m
//  04-基本图形绘制
//
//  Created by Gavin on 15/7/28.
//  Copyright © 2015年 Gavin. All rights reserved.
//

/*
    3. 开始绘图,drawRect方法中
      3.1:获取跟当前View相关联的上下文
          目前所学的上下文都是以UIGraphics开头的
          CGContextRef ctx = UIGraphicsGetCurrentContext();
          绘图都是C语言的
          进放头文件,查看CGContext它是一个结构体指针
          注意点:获取的上下文是系统帮我们创建的.
 
      3.2:拼接路径
          PPT绘图演示,想要画线,首先是两点成一线.第一步设置起点,然后从起点到某个点
          最常用的路径:UIBezierPath
          它内部已经封装好了一套很好使用的路径.
             3.2.1设置起点
             [path moveToPoint:CGPointMake(10, 125)];
             3.2.2添加一根线到某个点
             [path addLineToPoint:CGPointMake(240, 125)];
 
          拼接完路径,让它显示到上下文中,PPT演示,要把画的内容添加到上下文
 
     3.3:添加路径到上下文
         添加路径到上下文
         CGContextAddPath(ctx, path);
         发现为报错:
         原因:它要求传入的类型是CGPathRef,它是CoreGraphics框架的.
         我们现在用的路径是UIKit框架中的,传进去报错原因类型不匹配.
         解决办法:把UIKit path 转换成-> CoreGraphics Path
            
        在UIBezierPath已经提供了一个属性,将当前的Path转成 CGPathRef
        - (CGPathRef)CGPath
        现在已经把路径添加到上下文中
 
    3.4:渲染到View上面的图层上面
        描边一个路径到上下文中
        CGContextStrokePath(ctx);
 
    原理:为什么要一个上下文?
        这个上下文叫做内存缓存区,
        以后可能画很多线,画很多内容
        渲染是很耗内存的,所以它是让你把所有的东西全部画好之后,最后做一次渲染.
    
 
    4.如果想再画一根线怎么办?
 
       两种解决方法:1.再添加一个路径,设置一个起点,添加一根线到某一个点
                  2.直接在原有的路径上进行拼接
       采用第二种: [path addLineToPoint:CGPointMake(240, 150)];
       说明一个路径可以对应多根线.
       默认下一根线的起点,就是上一根线的终点
 
    5.想要设置线的颜色怎么办?设置上下文的一个状态.
 
      有上下文,我们就找CGContext
      设置颜色: 整个路径全部变成红色了
      [[UIColor redColor] setStroke];
      [[UIColor redColor] set];
 
      设置线宽
      CGContextSetLineWidth(ctx, 10);
 
      设置线段的连接样式
      CGContextSetLineJoin(ctx, kCGLineJoinRound);
 
      添加顶角样式
      CGContextSetLineCap(ctx, kCGLineCapRound);
 
      
     注意:添加上下文的状态,它是有顺序的
         如果把它放到渲染后面,是没有效果的.
         应该放到渲染之前去执行.
 
     提问:如果把它放到添加路径之前有没有效果?
          也是有效果的.验证, 说明,只要在渲染之前就OK的
 
 
 
    6.画曲线
      回顾画图的步骤
      获取上下文
      添加路径
      添加路径到上下文
      渲染上下文
     6.1.获取上下文
     CGContextRef ctx = UIGraphicsGetCurrentContext();
     6.2添加路径
     UIBezierPath *path = [UIBezierPath bezierPath];
     [path moveToPoint:CGPointMake(10, 125)];
     controlPoint为控制点
     [path addQuadCurveToPoint:CGPointMake(240, 125) controlPoint:CGPointMake(125, 10)];
     6.3添加路径到上下文
     CGContextAddPath(ctx, path.CGPath);
     6.4渲染上下文
     CGContextStrokePath(ctx);
 

    7.画形状
      7.1:画矩形
         获取上下文
         CGContextRef ctx = UIGraphicsGetCurrentContext();
         添加路径
         UIBezierPath *path = [UIBezierPath bezierPathWithRect:CGRectMake(10, 100, 50, 50)];
         添加路径到上下文
         CGContextAddPath(ctx, path.CGPath);
         渲染上下文
         CGContextStrokePath(ctx);
         在这里还可以用填充,只有一个封闭的路径才可以填充,如果不是封闭的路径,它会先把你的路径给封闭
         填充,默认填充颜色为黑色
         CGContextFillPath(ctx);
         设置填充颜色为红色
         [[UIColor redColor] setFill];

        如果想让它既有描边,又有填充
         [[UIColor greenColor] setStroke];
         [[UIColor redColor] setFill];
        运行发现没有描边效果
        原因:因为渲染的模式不对,渲染的时候直接说的是填充 CGContextFillPath(ctx);
        解决:设置渲染的模式为->kCGPathFillStroke
        要用另外一个方法->CGContextDrawPath(ctx, kCGPathFillStroke);
 
 
      7.2:画圆
         UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(10, 100, 50, 50)];
        宽和高不一样,它就会变成椭圆
 
     7.3:圆角矩形
        cornerRadius:圆角的半径
        ppt画图演示圆角的半径
        圆角半径特于矩形宽度的一半,就是一个圆
        UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(10, 100, 50, 50) cornerRadius:10];
 
    8.利用UIKit封装的上下文进行画图
 
        UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(10, 50, 100, 100) cornerRadius:50];
        [path stroke];
 
        它底层的实现,就是获取上下文,拼接路径,把路径添加到上下文,渲染到View
        怎么样验证它有没有上下文
        验证:一开始让它在awakeFromNib里面,看它会不会画
        结果:没有画东西,控制台会报一堆信息
        结论:虽然表面上没有用到上下文,其实它底层已经给你封装好了,它的底层还是会获取上下文
            只有在drawRect方法里面才能获取上下文.所以必须要在drawRect方法里面去画.
        以后不管是否需要上下文,只要绘制东西,都要在drawRect方法中写,才能显示到View上
 
    9.画圆弧
        
        PPT演示圆弧的样子
        画圆弧首先要有什么条件?
        首先要确定圆才能确定圆弧,圆孤它就圆上的一个角度嘛
 
         Center:圆心
         radius:圆的半径
         startAngle:起始角度
         endAngle:终点角度
         clockwise:Yes顺时针,No逆时针
 
         UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(125, 125) radius:100 startAngle:0 endAngle:M_PI * 2 clockwise:YES];
         [path stroke];
 
        PPT:演示,startAngle角度的位置
        说明:这里的角度是一个孤度制
    
        逆时针画一个半圆
        UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(125, 125) radius:100 startAngle:0 endAngle:M_PI clockwise:NO];
        [path stroke];
        
        4分之1圆孤
         UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(125, 125) radius:100 startAngle:0 endAngle:-M_PI_2 clockwise:NO];
         [path stroke];
 
    10.画1/4的扇形
 
        PPT演示扇形的形状,
        说明, 先画一个圆孤再添加一个一根线到圆心
         UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(125, 125) radius:100 startAngle:0 endAngle:-M_PI_2 clockwise:NO];
         添加一根线到圆心
         [path addLineToPoint:CGPointMake(125, 125)];
         关闭路径,从路径的终点到路径的起点
         [path closePath];
         [path stroke];
         用填充的话,它会默认做一个封闭路径,从路径的终点到起点. 
         [path fill];
 
*/

#import "LineView.h"

@implementation LineView


-(void)awakeFromNib{
   
}



//drawRect:就是用来绘图用的
- (void)drawRect:(CGRect)rect {


    //Center:圆心
    //radius:圆的半径
    //startAngle:起始角度
    //endAngle:终点角度
    //clockwise:Yes顺时针,No逆时针
//    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(125, 125) radius:100 startAngle:0 endAngle:M_PI * 2 clockwise:YES];
//    [path stroke];
    
//    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(125, 125) radius:100 startAngle:0 endAngle:M_PI clockwise:NO];
//    [path stroke];
    
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(125, 125) radius:100 startAngle:0 endAngle:-M_PI_2 clockwise:NO];
    
    
    
    //添加一根线到圆心
    [path addLineToPoint:CGPointMake(125, 125)];
    //关闭路径
    [path closePath];
//    [path stroke];
    [path fill];
    
    
}



- (void)UIKitBezsier{

    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(10, 50, 100, 100) cornerRadius:50];
    [path stroke];
}




- (void)drawShap{
    
    //    获取上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    //    添加路径]
    //画圆
    //    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(10, 100, 50, 50)];
    //画圆角矩形
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(10, 100, 50, 50) cornerRadius:10];
    
    //    添加路径到上下文
    CGContextAddPath(ctx, path.CGPath);
    //    渲染上下文
    //    CGContextStrokePath(ctx);
    
    [[UIColor greenColor] setStroke];
    [[UIColor redColor] setFill];
    //    CGContextFillPath(ctx);
    CGContextDrawPath(ctx, kCGPathFillStroke);

}




- (void)drawRectPath{
    // 获取上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    // 添加路径
    UIBezierPath *path = [UIBezierPath bezierPathWithRect:CGRectMake(10, 100, 50, 50)];
    // 添加路径到上下文
    CGContextAddPath(ctx, path.CGPath);
    // 渲染上下文
    // CGContextStrokePath(ctx);
    
    
    [[UIColor greenColor] setStroke];
    [[UIColor redColor] setFill];
    //    CGContextFillPath(ctx);
    CGContextDrawPath(ctx, kCGPathFillStroke);
    
    
    
}



//画曲线
- (void)drawCurve{
    
    //1.获取上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    //添加路径
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(10, 125)];
    [path addQuadCurveToPoint:CGPointMake(240, 125) controlPoint:CGPointMake(125, 10)];
    //添加路径到上下文
    CGContextAddPath(ctx, path.CGPath);
    //渲染上下文
    CGContextStrokePath(ctx);
}


//画直线
- (void)drawLine{
    
    //1.获取跟View相关联的上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    //2.拼接路径,最常用的路径
    UIBezierPath *path = [UIBezierPath bezierPath];
    //2.1设置起点
    [path moveToPoint:CGPointMake(10, 125)];
    //2.2添加一根线到某个点
    [path addLineToPoint:CGPointMake(200, 125)];
    [path addLineToPoint:CGPointMake(200, 150)];
    
    [[UIColor redColor] setStroke];
    //3.添加路径到上下文
    //    CGContextAddPath(ctx, path);
    CGContextAddPath(ctx,path.CGPath);
    //设置线宽
    CGContextSetLineWidth(ctx, 20);
    //设置线段的连接样式
    CGContextSetLineJoin(ctx, kCGLineJoinRound);
    //添加顶角样式
    CGContextSetLineCap(ctx, kCGLineCapRound);
    //4.渲染到View上面
    CGContextStrokePath(ctx);
}




@end
