//
//  ViewController.m
//  图片水印
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//
/*
    1.PPT演示,水印
 
        说明做水印,是在一个图片上面添加一些文字,Logo,生成一张新的图片
        回顾上下文的类型,之前都是在UIView上绘制一些东西, 用的都是跟UIView相关联的上下文,
        只有在DrawRect方法中才能获得跟View相关联的上下文.所以要自定义View
 
        现在生成一张图片,要用到位图上下文.
        位图上下文必须得要自己创建.这个位图上下文要自己管理了.
 
        size:上下文的尺寸
        opaque:不透明度 Yes:不透明,No:透明
        scale:是否缩放上下文, 0: 表示不缩放
        UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    2.代码生成水印图片
 
        导入素材
        UIImage *image = [UIImage imageNamed:@"阿狸头像"];
        创建一个位图上下文,上下文的尺寸和我们的的图片一样大
        UIGraphicsBeginImageContextWithOptions(image.size, NO, 0);
 
        把刚才导入的图片绘制到图片上下文上
        [image drawAtPoint:CGPointZero];
        在上面添加一些文字
        NSString *str = @"小码哥";
        [str drawAtPoint:CGPointZero withAttributes:nil];
        根据上下文的内容生成一张图片
        image = UIGraphicsGetImageFromCurrentImageContext();
        _imageV.image = image;
        PPT说明:生成完图片之后,位图上下文还在那个地方.
        关闭位图上下文,自己创建的上下文要自己管理
        UIGraphicsEndImageContext();
 
   3. 将图片写入到桌面
         
        我们桌面上传输东西都是以二进流的形式去传输.
        NSData才是二进制流.
        所以要把Image转换成NSData,
        将一张图片转换成二进制流
        NSData *data = UIImageJPEGRepresentation(image, 1);
        将二制流写入到桌面
        [data writeToFile:@"/Users/gaoxinqiang/Desktop/image.jpg" atomically:YES];
 
 
 
 */


#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIImage *image = [UIImage imageNamed:@"阿狸头像"];
    
    
    //size:上下文的尺寸
    //opaque:不透明度 Yes:不透明,No:透明
    //scale:是否缩放上下文, 0: 表示不缩放
    //水印的图片大小, 和原来的尺寸一样大
    //创建一个位图上下文
    UIGraphicsBeginImageContextWithOptions(image.size, NO, 0);
    //在位图上下文面绘制一个图片
    [image drawAtPoint:CGPointZero];
    
    //在上面添加一些文字
    NSString *str = @"小码哥";
    [str drawAtPoint:CGPointZero withAttributes:nil];
    
    //根据上下文的内容生成一张图片
    image = UIGraphicsGetImageFromCurrentImageContext();
    
    _imageV.image = image;
    
    //关闭位图上下文
    UIGraphicsEndImageContext();
    
    //将一张图片转换成二进制流
    NSData *data = UIImageJPEGRepresentation(image, 1);
    //将二制流写入到桌面
    [data writeToFile:@"/Users/gaoxinqiang/Desktop/image.jpg" atomically:YES];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
