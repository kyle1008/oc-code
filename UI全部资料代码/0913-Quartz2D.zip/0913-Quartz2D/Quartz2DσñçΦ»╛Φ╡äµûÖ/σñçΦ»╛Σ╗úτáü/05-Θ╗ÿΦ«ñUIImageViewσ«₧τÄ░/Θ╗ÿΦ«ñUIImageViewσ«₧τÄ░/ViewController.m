//
//  ViewController.m
//  默认UIImageView实现
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//

/*
    1.模仿系统ImageView
        先看一下系统ImageView是怎么用的
        UIImageView *imageV = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 50, 50)];
        imageV.image = [UIImage imageNamed:@"CTO"];
        [self.view addSubview:imageV];
        系统的用法,想要模仿系统的用法,同样也要设一个image属性,设置图片
    2.新建自己的imageView
        新建一个View,起名XMGImageView,同样设置一个UIImage属性,起名,image
        导入XMGImageView头文件
        调用自己的ImageView和系统的写法一样
 
        XMGImageView *imageV = [[XMGImageView alloc] initWithFrame:CGRectMake(50, 50, 100, 100)];
        imageV.image = [UIImage imageNamed:@"CTO"];
        [self.view addSubview:imageV];
        
        运行什么都不显示,是因为对自己的imageView内部什么处理都没有做, 所以他都没有反应.
        要在drawRect进行绘图
         - (void)drawRect:(CGRect)rect {
             用drawInRect,图片要跟我的尺寸一样大,
             [_image drawInRect:rect];
         }
        运行:发现能够看到图片,
            先调用ViewDidLoad,再调用drawRect方法, 所以能够看到,因为这个时间,image已经有值了
    3.切换图片
        假设点击屏幕的时候就让它切换图片,
        先用系统的方法进行切换,用一个成员属性记录UIImageView
        @property(nonatomic,weak) UIImageView *imageView;
 
         UIImageView *sysImageV = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 100, 100)];
          _imageView = sysImageV;
         - (void)touchesBegan:(nonnull NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
             _imageView.image = [UIImage imageNamed:@"汽水"];
         }
 
        系统的一点就会切换图片
        演示自己写的.
        自己写的图片不能够一点就让它切换图片
        
        想要切换图片,就是当用户一点的时候,就让图片重新绘制一下.
        要重写XMGImageView的image属性的Set方法,在Set方法中,让它重新绘制
         -(void)setImage:(UIImage *)image{
             _image = image;
             [self setNeedsDisplay];
         }
        演示自己写的XMGImageView,也能够切换图片.
 
    4.系统的ImageView有一个方法:
      默认调用initWithImage,控件尺寸跟图片尺寸一样大
      UIImageView *image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"CTO"]];
      自己封装的东西也要提供这样一个方法.
      所以自己写的XMGImageView,要提供一个这样的方法
     - (instancetype)initWithImage:(UIImage *)image;
        
     - (instancetype)initWithImage:(UIImage *)image{
         先初始化父类
         if (self = [super init]) {
        让自己控件的大小和传进来的Image尺寸一样大
        self.frame = CGRectMake(0, 0, image.size.width, image.size.height);
        给自己的成员属性赋值,让它绘制到View上面
        _image = image;
         }
         return self;
     }

 */


#import "ViewController.h"
#import "XMGImageView.h"
@interface ViewController ()

@property(nonatomic,weak) UIImageView *imageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    
//    UIImageView *sysImageV = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 100, 100)];
//    _imageView = sysImageV;
    UIImageView *image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"CTO"]];
    [self.view addSubview:image];
    
//    XMGImageView *imageV = [[XMGImageView alloc] initWithFrame:CGRectMake(50, 50, 100, 100)];
//    imageV.image = [UIImage imageNamed:@"CTO"];
//    _imageView = imageV;
//    [self.view addSubview:imageV];
    
    XMGImageView *imageV = [[XMGImageView alloc] initWithImage:[UIImage imageNamed:@"CTO"]];
    [self.view addSubview:imageV];
    
    


}

- (void)touchesBegan:(nonnull NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
    _imageView.image = [UIImage imageNamed:@"汽水"];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
