//
//  XMGImageView.m
//  默认UIImageView实现
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "XMGImageView.h"

@implementation XMGImageView

- (instancetype)initWithImage:(UIImage *)image{

    if (self = [super init]) {
        self.frame = CGRectMake(0, 0, image.size.width, image.size.height);
        _image = image;
    }
    return self;
}

-(void)setImage:(UIImage *)image{
    
    _image = image;
    [self setNeedsDisplay];
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    //用drawInRect,图片要跟我的尺寸一样大,
    [_image drawInRect:rect];
    
}


@end
