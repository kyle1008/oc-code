//
//  ViewController.m
//  裁剪图片
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//
/*
    1.PPT分析思路
 
        把图片拖入到PPT,开启一个和图片一样大的上下文,才不会把图片给拉伸,
        裁剪图片, 先设置裁剪区域,再进行绘制
        裁剪一个圆, 这个圆,正切于图片,它的两倍的半径刚好特于宽高.
        再把图片画上去,超出裁剪区域的会自动裁剪掉
 
    2.新建工程,导入素材,简单的图片裁剪
 
        导入要裁剪的图片
        UIImage *image = [UIImage imageNamed:@"阿狸头像"];
        开启位图上下文
        位图上下文的大小和导入的图片大小一样,为了是不让图片拉伸
        UIGraphicsBeginImageContextWithOptions(CGSizeMake(image.size.width, image.size.height),   NO, 0);
         绘制圆形裁剪区域  裁剪区域的大小等于图片的尺寸
         UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
 
         让绘制的路径成为裁剪区域,超出裁剪区域的内容会自动裁剪掉
         [path addClip];
         把导入的图片画到位图上下文
         [image drawAtPoint:CGPointZero];
         从位图上下文中取出图片
         image =  UIGraphicsGetImageFromCurrentImageContext();
         _imageV.image = image;
         关闭图形上下文
         UIGraphicsEndImageContext();
 
 */



#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIImage *image = [UIImage imageNamed:@"阿狸头像"];
//     开启位图上下文
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(image.size.width, image.size.height), NO, 0);
    //绘制裁剪区域
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
    
    //让绘制的路径成为裁剪区域
    [path addClip];
    //把导入的图片画到位图上下文
    [image drawAtPoint:CGPointZero];
    
    //从位图上下文中取出图片
     image =  UIGraphicsGetImageFromCurrentImageContext();
    _imageV.image = image;
    //关闭图形上下文
    UIGraphicsEndImageContext();
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
