//
//  ViewController.m
//  绘制饼图
//
//  Created by Gavin on 15/7/28.
//  Copyright © 2015年 Gavin. All rights reserved.
//
/*
    1.分析
        由3个扇形组成的一个圆,就是一个饼图,
        首先会提供一组数据给你.假设给一组数据. 分成3份 
        第一个扇形假设从0开始画,
        第一个起始角度为0,第一个结束角度刚好是25 /100.0,看它占整个圆的多少度,占90度圆孤
        它的角度随着数据改变而改变,
        angel = 25 / 100.0 * M_PI * 2;
        结束角度等于上一个角度,加上自己占有的角度,
 
        分析完第一个, 再分析第二个
        第二个它是从上一个扇形的结束角度开始画
        StartA = endA
        计算第二个扇形占有的角度
 
    2.拖一个View当做画板,自定义View PieView,绑定View
 
 

*/

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
