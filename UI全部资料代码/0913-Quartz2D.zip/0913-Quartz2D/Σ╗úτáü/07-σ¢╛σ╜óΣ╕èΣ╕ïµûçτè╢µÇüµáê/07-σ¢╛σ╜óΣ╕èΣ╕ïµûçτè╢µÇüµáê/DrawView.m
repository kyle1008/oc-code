//
//  DrawView.m
//  07-图形上下文状态栈
//
//  Created by Gavin on 15/9/13.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "DrawView.h"

@implementation DrawView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    
    //1.获取跟View相关联的上下文
   CGContextRef ctx = UIGraphicsGetCurrentContext();
    //2.描述路径
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    //添加横线
    [path moveToPoint:CGPointMake(10, 150)];
    [path addLineToPoint:CGPointMake(290, 150)];

    //把当前的状态保存到图片上下文状态栈里.
    CGContextSaveGState(ctx);

    
    [[UIColor redColor] set];
    CGContextSetLineWidth(ctx, 10);
    
    
    //3.把路径添加到上下文
    CGContextAddPath(ctx, path.CGPath);

    //4.把上下文的内容渲染出来.
    CGContextStrokePath(ctx);
    
    
    path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(150, 10)];
    [path addLineToPoint:CGPointMake(150, 290)];

    
    //恢复上下文状态栈
    CGContextRestoreGState(ctx);
    
    
    //3.把路径添加到上下文
    CGContextAddPath(ctx, path.CGPath);
    
    //4.把上下文的内容渲染出来.
    CGContextStrokePath(ctx);
    
    
}


@end
