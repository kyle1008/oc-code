//
//  RedView.m
//  04-UIKit绘图
//
//  Created by Gavin on 15/9/13.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "RedView.h"

@implementation RedView



-(void)awakeFromNib{
    


    
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    //1.加载图片
    UIImage *image = [UIImage imageNamed:@"001"];
    
    //绘制出来的图片,是保持原来图片
//        [image drawAtPoint:CGPointZero];
    //把图片填充到这个rect当中.
//        [image drawInRect:rect];
    //添加裁剪区域 .把超区裁剪区域以外都裁剪掉
//    UIRectClip(CGRectMake(0, 0, 50, 50));
//    [image drawAsPatternInRect:self.bounds];
    
    
    
    [[UIColor blueColor] set];
    UIRectFill(CGRectMake(10, 10, 100, 100));
    

}


- (void)drawText{
    NSString *str = @"小码哥小码哥小码哥小码哥";
    
    //AtPoint:文字所画的位置
    //withAttributes:描述文字的属性.
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    //设置文字大小
    dict[NSFontAttributeName] = [UIFont systemFontOfSize:50];
    
    //设置文字颜色
    dict[NSForegroundColorAttributeName] = [UIColor greenColor];
    //设置描边宽度
    dict[NSStrokeWidthAttributeName] = @2;
    //设置描边颜色
    dict[NSStrokeColorAttributeName] = [UIColor blueColor];

    
    //设置阴影
    NSShadow *shadow = [[NSShadow alloc] init];
    //设置阴影的便宜量
    shadow.shadowOffset = CGSizeMake(10, 10);
    //设置阴影颜色
    shadow.shadowColor = [UIColor greenColor];
    //设置阴影模糊程序
    shadow.shadowBlurRadius = 1;
    dict[NSShadowAttributeName] = shadow;
    //不会自动换行
    [str drawAtPoint:CGPointZero withAttributes:dict];
    //会自动换行.
    [str drawInRect:self.bounds withAttributes:dict];
}



@end
