//
//  ViewController.m
//  05-模仿UIImageView
//
//  Created by Gavin on 15/9/13.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"
#import "XMGImageView.h"
@interface ViewController ()
@property(nonatomic,weak) UIImageView *imageV;
@property(nonatomic,weak)XMGImageView *xmgImageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    UIImageView *imageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"阿狸头像"]];
//    self.imageV = imageV;
//    [self.view addSubview:imageV];

    XMGImageView *xmgImageV = [[XMGImageView alloc] initWithImage:[UIImage imageNamed:@"阿狸头像"]];
    self.xmgImageV = xmgImageV;
    [self.view addSubview:xmgImageV];
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    self.xmgImageV.image = [UIImage imageNamed:@"001"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
