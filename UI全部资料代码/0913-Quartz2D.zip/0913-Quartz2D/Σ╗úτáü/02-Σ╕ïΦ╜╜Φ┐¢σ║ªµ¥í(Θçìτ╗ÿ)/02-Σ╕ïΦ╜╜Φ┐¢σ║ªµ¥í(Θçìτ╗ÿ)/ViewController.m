//
//  ViewController.m
//  02-下载进度条(重绘)
//
//  Created by xiaomage on 15/9/13.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"
#import "ProgressView.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *textLabel;
@property (weak, nonatomic) IBOutlet ProgressView *progressView;

@end

@implementation ViewController


- (IBAction)valueChange:(UISlider *)sender {
   
    NSLog(@"%f",sender.value);
    //在stringWithFormat %有特殊的含义,我们要显示%,用两个%代表一个%
    self.textLabel.text = [NSString stringWithFormat:@"%.2f%%",sender.value * 100];
    
    self.progressView.progress = sender.value;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
