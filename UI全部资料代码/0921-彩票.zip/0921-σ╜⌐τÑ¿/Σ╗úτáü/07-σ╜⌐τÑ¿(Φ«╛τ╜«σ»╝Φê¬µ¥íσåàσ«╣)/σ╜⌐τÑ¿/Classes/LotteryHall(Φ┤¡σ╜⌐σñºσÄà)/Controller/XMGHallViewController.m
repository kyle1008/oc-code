//
//  XMGHallViewController.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGHallViewController.h"

@interface XMGHallViewController ()

@end

@implementation XMGHallViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    NSLog(@"%@",NSStringFromCGRect(self.view.frame));
}
@end
