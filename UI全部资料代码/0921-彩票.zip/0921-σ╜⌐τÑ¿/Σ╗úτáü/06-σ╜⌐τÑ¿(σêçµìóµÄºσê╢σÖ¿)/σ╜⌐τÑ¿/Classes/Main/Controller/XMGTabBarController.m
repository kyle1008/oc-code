//
//  XMGTabBarController.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGTabBarController.h"

#import "XMGHallViewController.h"
#import "XMGArenaViewController.h"
#import "XMGDiscoverViewController.h"
#import "XMGHistoryViewController.h"
#import "XMGMyLotteryViewController.h"

#import "XMGTabBar.h"

@interface XMGTabBarController ()<XMGTabBarDelegate>

// 记录每个子控制器对应按钮的模型
@property (nonatomic, strong) NSMutableArray *items;

@end

@implementation XMGTabBarController
// UITabBarButton上面的图片尺寸是有规格,不能太大,如果太大,就显示不出来.
// 系统的UITabBarButton不能显示我们美工提供的图片,系统的UITabBarButton不能完成我们需求,UITabBarButton不好使.
// 自定义按钮,显示在UITabBar
// 需不需要系统自带的UITabBarButton,把系统自带的UITabBarButton移除
// 直接把系统的UITabBar移除
// 自定义UITabBar,添加到tabBarVc上

- (NSMutableArray *)items
{
    if (_items == nil) {
        _items = [NSMutableArray array];
    }
    return _items;
}

// viewDidLoad:做控制器的初始化操作
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 添加所有子控制器
    [self setUpAllChildViewController];
    
    // 自定义tabBar
    [self setUpTabBar];
    
    // 切换界面 竞技场
//    self.selectedViewController = self.childViewControllers[1];
    
}

#pragma mark - 自定义tabBar
- (void)setUpTabBar
{
    // 在ARC中,一个对象没有被强引用,并不会马上销毁,什么时候销毁,在下一次运行循环到来的时候,系统会自动判断当前哪些对象,没有强引用,没有强引用,就会销毁
    // 1.移除系统的tabBar
    [self.tabBar removeFromSuperview];
    
    
    // 2.添加自己的tabBar
    // 2.1 创建UIView,代替系统的tabBar
    XMGTabBar *tabBar = [[XMGTabBar alloc] initWithFrame:self.tabBar.frame];
    tabBar.delegate = self;
    // 记录下tabBar里面有几个按钮
    // 系统的tabBar里面有多少个按钮是由tabBarVc的子控制器总数
    // 把对应按钮的模型数组
    tabBar.items = self.items;

    tabBar.backgroundColor = [UIColor blueColor];
    [self.view addSubview:tabBar];
    
  
}

#pragma mark- XMGTabBarDelegate
// 点击底部的按钮,切换控制器
- (void)tabBar:(XMGTabBar *)tabBar didClickBtn:(NSInteger)buttonIndex
{
    self.selectedIndex = buttonIndex;
}

#pragma mark - 添加所有的子控制器
- (void)setUpAllChildViewController
{
    // 1.购彩大厅
    XMGHallViewController *hall = [[XMGHallViewController alloc] init];
    // 添加tabBarVc子控制器,并且设置对应对应按钮的内容
    [self setUpOneChildViewController:hall image:[UIImage imageNamed:@"TabBar_LotteryHall_new"] selImage:[UIImage imageNamed:@"TabBar_LotteryHall_selected_new"]];
    
    // 2.竞技场
    XMGArenaViewController *arena = [[XMGArenaViewController alloc] init];
    arena.view.backgroundColor = [UIColor yellowColor];
    [self setUpOneChildViewController:arena image:[UIImage imageNamed:@"TabBar_Arena_new"] selImage:[UIImage imageNamed:@"TabBar_Arena_selected_new"]];
    
    // 3.发现
    XMGDiscoverViewController *discover = [[XMGDiscoverViewController alloc] init];
    [self setUpOneChildViewController:discover image:[UIImage imageNamed:@"TabBar_Discovery_new"] selImage:[UIImage imageNamed:@"TabBar_Discovery_selected_new"]];
    
   
    
    // 4.开奖信息
    XMGHistoryViewController *history = [[XMGHistoryViewController alloc] init];
    [self setUpOneChildViewController:history image:[UIImage imageNamed:@"TabBar_History_new"] selImage:[UIImage imageNamed:@"TabBar_History_selected_new"]];

    
    // 5.我的彩票
    XMGMyLotteryViewController *myLottery = [[XMGMyLotteryViewController alloc] init];
    [self setUpOneChildViewController:myLottery image:[UIImage imageNamed:@"TabBar_MyLottery_new"] selImage:[UIImage imageNamed:@"TabBar_MyLottery_selected_new"]];
    
   
}

// 添加一个子控制器
- (void)setUpOneChildViewController:(UIViewController *)vc image:(UIImage *)image selImage:(UIImage *)selImage
{
  
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    
    // 设置对应tabBarButton内容,由对应的子控制器
    nav.tabBarItem.image = image;
    nav.tabBarItem.selectedImage = selImage;
    
    // 保证对应按钮的模型
    [self.items addObject:nav.tabBarItem];
    
    
    [self addChildViewController:nav];

}


@end
