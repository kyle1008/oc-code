//
//  XMGTabBar.h
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//  模仿系统的tabBar

// 如何封装控件:先看外界怎么用
#import <UIKit/UIKit.h>

@class XMGTabBar;

@protocol XMGTabBarDelegate <NSObject>

@optional
- (void)tabBar:(XMGTabBar *)tabBar didClickBtn:(NSInteger)buttonIndex;

@end


@interface XMGTabBar : UIView

@property (nonatomic, weak) id<XMGTabBarDelegate> delegate;

// items:UITabBarItem
@property (nonatomic, strong) NSArray *items;


@end
