//
//  XMGTabBarController.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGTabBarController.h"

#import "XMGHallViewController.h"
#import "XMGArenaViewController.h"
#import "XMGDiscoverViewController.h"
#import "XMGHistoryViewController.h"
#import "XMGMyLotteryViewController.h"

@interface XMGTabBarController ()

@end

@implementation XMGTabBarController
// UITabBarButton上面的图片尺寸是有规格,不能太大,如果太大,就显示不出来.
// 系统的UITabBarButton不能显示我们美工提供的图片,系统的UITabBarButton不能完成我们需求,UITabBarButton不好使.
// 自定义按钮,显示在UITabBar
// 需不需要系统自带的UITabBarButton,把系统自带的UITabBarButton移除
// 直接把系统的UITabBar移除
// 自定义UITabBar,添加到tabBarVc上

// viewDidLoad:做控制器的初始化操作
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 添加所有子控制器
    [self setUpAllChildViewController];
    
    // 自定义tabBar
    [self setUpTabBar];
}

#pragma mark - 自定义tabBar
- (void)setUpTabBar
{
    // 1.移除系统的tabBar
    [self.tabBar removeFromSuperview];
    
    // 2.添加自己的tabBar
    
}

#pragma mark - 添加所有的子控制器
- (void)setUpAllChildViewController
{
    // 1.购彩大厅
    XMGHallViewController *hall = [[XMGHallViewController alloc] init];
    // 添加tabBarVc子控制器,并且设置子控制器对应按钮的内容
    [self setUpOneChildViewController:hall image:[UIImage imageNamed:@"TabBar_LotteryHall_new"] selImage:[UIImage imageNamed:@"TabBar_LotteryHall_selected_new"]];
    
    // 2.竞技场
    XMGArenaViewController *arena = [[XMGArenaViewController alloc] init];
    [self setUpOneChildViewController:arena image:[UIImage imageNamed:@"TabBar_Arena_new"] selImage:[UIImage imageNamed:@"TabBar_Arena_selected_new"]];
    
    // 3.发现
    XMGDiscoverViewController *discover = [[XMGDiscoverViewController alloc] init];
    [self setUpOneChildViewController:discover image:[UIImage imageNamed:@"TabBar_Discovery_new"] selImage:[UIImage imageNamed:@"TabBar_Discovery_selected_new"]];
    
    // 4.开奖信息
    XMGHistoryViewController *history = [[XMGHistoryViewController alloc] init];
    [self setUpOneChildViewController:history image:[UIImage imageNamed:@"TabBar_History_new"] selImage:[UIImage imageNamed:@"TabBar_History_selected_new"]];

    // 5.我的彩票
    XMGMyLotteryViewController *myLottery = [[XMGMyLotteryViewController alloc] init];
    [self setUpOneChildViewController:myLottery image:[UIImage imageNamed:@"TabBar_MyLottery_new"] selImage:[UIImage imageNamed:@"TabBar_MyLottery_selected_new"]];
}

#pragma mark - 添加tabBarVc子控制器,并且设置子控制器对应按钮的内容
- (void)setUpOneChildViewController:(UIViewController *)vc image:(UIImage *)image selImage:(UIImage *)selImage
{
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    
    // 设置对应tabBarButton内容,由对应的子控制器
    nav.tabBarItem.image = image;
    nav.tabBarItem.selectedImage = selImage;
    
    [self addChildViewController:nav];

}


@end
