//
//  XMGTabBarController.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGTabBarController.h"

#import "XMGHallViewController.h"
#import "XMGArenaViewController.h"
#import "XMGDiscoverViewController.h"
#import "XMGHistoryViewController.h"
#import "XMGMyLotteryViewController.h"

@interface XMGTabBarController ()

@end

@implementation XMGTabBarController

// viewDidLoad:做控制器的初始化操作
- (void)viewDidLoad {
    [super viewDidLoad];

    // 添加所有子控制器
    [self setUpAllChildViewController];
  
}

#pragma mark - 添加所有的子控制器
- (void)setUpAllChildViewController
{
    // 1.购彩大厅
    XMGHallViewController *hall = [[XMGHallViewController alloc] init];
    [self setUpOneChildViewController:hall];
    
    // 2.竞技场
    XMGArenaViewController *arena = [[XMGArenaViewController alloc] init];
    [self setUpOneChildViewController:arena];
    
    // 3.发现
    XMGDiscoverViewController *discover = [[XMGDiscoverViewController alloc] init];
    
    [self setUpOneChildViewController:discover];
    
    // 4.开奖信息
    XMGHistoryViewController *history = [[XMGHistoryViewController alloc] init];
    [self setUpOneChildViewController:history];
    
    // 5.我的彩票
    XMGMyLotteryViewController *myLottery = [[XMGMyLotteryViewController alloc] init];
    [self setUpOneChildViewController:myLottery];
   
}

// 添加一个子控制器
- (void)setUpOneChildViewController:(UIViewController *)vc
{
  
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    
    [self addChildViewController:nav];

}


@end
