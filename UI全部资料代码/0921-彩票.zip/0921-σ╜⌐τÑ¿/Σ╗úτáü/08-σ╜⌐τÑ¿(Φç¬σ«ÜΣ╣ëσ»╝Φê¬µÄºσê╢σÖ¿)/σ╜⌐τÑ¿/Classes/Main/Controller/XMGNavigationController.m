//
//  XMGNavigationController.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGNavigationController.h"

@interface XMGNavigationController ()

@end

@implementation XMGNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 设置导航条背景色
    //    nav.navigationBar.backgroundColor = [UIColor redColor];
    // UIBarMetricsDefault:才能设置图片成功,其他的模式都设置不了
    // UIBarMetricsDefault效果: 使导航控制器的子控制器的view高度会减少64,会从导航条底部开始显示内容
    // UIBarMetricsCompact效果:导航条透明
    [self.navigationBar setBackgroundImage:[UIImage imageNamed:@"NavBar64"] forBarMetrics:UIBarMetricsDefault];
    
    // 设置导航条标题文字颜色
    // 创建描述字体的字典
    NSMutableDictionary *textAttr = [NSMutableDictionary dictionary];
    // 颜色
    textAttr[NSForegroundColorAttributeName] = [UIColor whiteColor];
    textAttr[NSFontAttributeName] = [UIFont boldSystemFontOfSize:17];
    
    // titleTextAttributes:给标题文字设置属性,(颜色,字体,阴影....)
    self.navigationBar.titleTextAttributes = textAttr;
}


@end
