//
//  XMGNavigationController.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGNavigationController.h"

@interface XMGNavigationController ()

@end

@implementation XMGNavigationController
// 什么调用:第一个次使用这个类或者它的子类的时候
// 不一定只会调用一次
+ (void)initialize
{
    if (self == [XMGNavigationController class]) {
        
        // 获取当前整个应用程序下的所有导航条的外观
        //    UINavigationBar *navBar = [UINavigationBar appearance];
        // 只影响当前类下面的导航条
        // 获取当前类下面的导航条
        UINavigationBar *navBar = [UINavigationBar appearanceWhenContainedIn:self, nil];
        
        // 设置导航条背景图片
        [navBar setBackgroundImage:[UIImage imageNamed:@"NavBar64"] forBarMetrics:UIBarMetricsDefault];
        // 设置导航条文字标题
        NSMutableDictionary *textAttr = [NSMutableDictionary dictionary];
        // 颜色
        textAttr[NSForegroundColorAttributeName] = [UIColor whiteColor];
        textAttr[NSFontAttributeName] = [UIFont boldSystemFontOfSize:17];
        
        // titleTextAttributes:给标题文字设置属性,(颜色,字体,阴影....)
        navBar.titleTextAttributes = textAttr;
    }
}
// 类加载的时候调用
// 这个才是只会调用一次
+ (void)load
{
    // 只想设置一次导航条的背景图片和导航条的标题
 
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // 设置导航条背景色
    //    nav.navigationBar.backgroundColor = [UIColor redColor];
    // UIBarMetricsDefault:才能设置图片成功,其他的模式都设置不了
    // UIBarMetricsDefault效果: 使导航控制器的子控制器的view高度会减少64,会从导航条底部开始显示内容
    // UIBarMetricsCompact效果:导航条透明
//    [self.navigationBar setBackgroundImage:[UIImage imageNamed:@"NavBar64"] forBarMetrics:UIBarMetricsDefault];
//    
//    // 设置导航条标题文字颜色
//    // 创建描述字体的字典
//    NSMutableDictionary *textAttr = [NSMutableDictionary dictionary];
//    // 颜色
//    textAttr[NSForegroundColorAttributeName] = [UIColor whiteColor];
//    textAttr[NSFontAttributeName] = [UIFont boldSystemFontOfSize:17];
//    
//    // titleTextAttributes:给标题文字设置属性,(颜色,字体,阴影....)
//    self.navigationBar.titleTextAttributes = textAttr;
}


@end
