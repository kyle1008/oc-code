//
//  Person.m
//  initial方法
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "Person.h"

@implementation Person

// 第一次使用这个类或者它的子类的时候调用
// 方法不一定只调用一次
+ (void)initialize
{
//    NSLog(@"%@",[self class]);
    // 就想要在这个方法做一次事情
    if (self == [Person class]) {
        
    }
}
+ (void)load
{
     NSLog(@"%@",[self class]);
}

@end
