//
//  XMGHallViewController.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGHallViewController.h"

#import "UIImage+Image.h"

@interface XMGHallViewController ()

@end

@implementation XMGHallViewController

// 插件路径:前往 -> 资源库 -> Application Support -> Developer

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 创建item
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithImage:[UIImage imageWithOriginalImageName:@"CS50_activity_image"] style:0 target:self action:@selector(activity)];
    
    self.navigationItem.leftBarButtonItem = item;
}



// 点击活动按钮就会调用
- (void)activity
{
    NSLog(@"%s",__func__);
}

@end
