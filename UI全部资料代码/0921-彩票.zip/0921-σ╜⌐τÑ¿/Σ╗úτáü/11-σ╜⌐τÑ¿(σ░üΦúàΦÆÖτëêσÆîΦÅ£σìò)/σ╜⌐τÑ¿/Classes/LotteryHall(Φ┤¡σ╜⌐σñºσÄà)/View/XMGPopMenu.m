//
//  XMGPopMenu.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGPopMenu.h"

// 开发思想:高聚合,低耦合

@interface XMGPopMenu()



@end

@implementation XMGPopMenu


- (void)hideInPoint:(CGPoint)point
{
    
    // pop菜单(平移+缩放)
    [UIView animateWithDuration:1 animations:^{
        
        self.center = point;
        
        // 形变
        self.transform = CGAffineTransformMakeScale(0.01, 0.01);
        
    } completion:^(BOOL finished) {
        // 移除
        [self removeFromSuperview];
    }];

}
// 点击关闭按钮
- (IBAction)close:(id)sender {
    
  
    
    // 通知代理,移除菜单 移除蒙版
    if ([_delegate respondsToSelector:@selector(popMenuDidClickClose:)]) {
        [_delegate popMenuDidClickClose:self];
    }
   
    
}

+ (instancetype)showInPoint:(CGPoint)point
{
   
    XMGPopMenu *menu = [[NSBundle mainBundle] loadNibNamed:@"XMGPopMenu" owner:nil options:nil][0];
    
    menu.center = point;
    
    // 获取主窗口
    [[UIApplication sharedApplication].keyWindow addSubview:menu];
    
    return menu;
}
@end
