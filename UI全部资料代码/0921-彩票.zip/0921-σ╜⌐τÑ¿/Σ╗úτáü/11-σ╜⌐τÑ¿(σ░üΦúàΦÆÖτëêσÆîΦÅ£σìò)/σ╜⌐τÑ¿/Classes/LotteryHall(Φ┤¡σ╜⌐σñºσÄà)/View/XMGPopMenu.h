//
//  XMGPopMenu.h
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XMGPopMenu;

@protocol XMGPopMenuDelegate <NSObject>

@optional
- (void)popMenuDidClickClose:(XMGPopMenu *)popMenu;

@end

@interface XMGPopMenu : UIView


@property (nonatomic, weak) id<XMGPopMenuDelegate> delegate;

+ (instancetype)showInPoint:(CGPoint)point;
- (void)hideInPoint:(CGPoint)point;

@end
