//
//  YZTabBarController.h
//  彩票
//
//  Created by yz on 15/6/25.
//  Copyright (c) 2015年 yz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZTabBarController : UITabBarController

@end
