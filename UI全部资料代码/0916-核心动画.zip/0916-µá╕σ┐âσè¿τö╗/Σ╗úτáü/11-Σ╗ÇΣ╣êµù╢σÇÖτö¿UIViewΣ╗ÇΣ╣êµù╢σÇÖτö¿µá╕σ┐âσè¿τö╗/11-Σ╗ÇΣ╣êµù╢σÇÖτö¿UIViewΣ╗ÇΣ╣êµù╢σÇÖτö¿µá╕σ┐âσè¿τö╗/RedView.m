//
//  RedView.m
//  11-什么时候用UIView什么时候用核心动画
//
//  Created by Gavin on 15/9/16.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "RedView.h"

@implementation RedView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


-(void)touchesBegan:(nonnull NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
    
    NSLog(@"%s",__func__);
}


@end
