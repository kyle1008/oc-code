//
//  YZContactTableViewController.m
//  QQ主流框架
//
//  Created by yz on 14-8-27.
//  Copyright (c) 2014年 iThinker. All rights reserved.
//

#import "YZContactTableViewController.h"

@interface YZContactTableViewController ()

@end

@implementation YZContactTableViewController
- (IBAction)valueChange:(UISegmentedControl *)sender {
    NSLog(@"%d",sender.selectedSegmentIndex);
}


- (void)viewDidLoad
{
    [super viewDidLoad];
 
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
     NSLog(@"%f",self.tableView.contentInset.top);
}



@end
