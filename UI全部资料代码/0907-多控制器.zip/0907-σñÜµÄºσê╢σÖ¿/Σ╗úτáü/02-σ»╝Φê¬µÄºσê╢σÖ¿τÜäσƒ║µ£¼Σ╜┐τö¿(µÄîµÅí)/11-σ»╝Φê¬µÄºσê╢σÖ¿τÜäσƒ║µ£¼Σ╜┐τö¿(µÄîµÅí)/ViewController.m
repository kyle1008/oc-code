//
//  ViewController.m
//  11-导航控制器的基本使用(掌握)
//
//  Created by xiaomage on 15/9/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

#import "TwoViewController.h"

@interface ViewController ()

@end

@implementation ViewController
- (IBAction)jump2Two:(id)sender {
    
    // 导航控制器永远显示栈顶控制器的view
    
    NSLog(@"%s",__func__);
    TwoViewController *twoVc = [[TwoViewController alloc] init];
    
    // 只有导航控制器才有跳转功能
    // 只要是导航控制器的子控制器就能拿到导航控制器
//    NSLog(@"%@",self.navigationController);
    [self.navigationController pushViewController:twoVc animated:YES];
    
    NSLog(@"%@",self.navigationController.childViewControllers);
    
    // 会把push的控制器添加为导航控制器的子控制器,而且会把新Push的控制器的view添加到导航控制器的view上
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
