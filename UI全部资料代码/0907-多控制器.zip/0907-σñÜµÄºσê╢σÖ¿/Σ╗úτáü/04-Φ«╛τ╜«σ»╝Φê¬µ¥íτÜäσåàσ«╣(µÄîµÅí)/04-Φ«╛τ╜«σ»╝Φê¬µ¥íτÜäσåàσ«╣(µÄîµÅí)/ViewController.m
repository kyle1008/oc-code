//
//  ViewController.m
//  04-设置导航条的内容(掌握)
//
//  Created by xiaomage on 15/9/7.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

#import "TwoViewController.h"



@interface ViewController ()

@end

@implementation ViewController
- (IBAction)jump2Two:(id)sender {
    
    TwoViewController *twoVc = [[TwoViewController alloc] init];
    
    [self.navigationController pushViewController:twoVc animated:YES];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    // 导航条的内容由栈顶控制器的navigationItem
    
    // 设置导航条标题
//    self.navigationItem.title = @"第一个界面";
    
    self.navigationItem.titleView = [UIButton buttonWithType:UIButtonTypeContactAdd];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
