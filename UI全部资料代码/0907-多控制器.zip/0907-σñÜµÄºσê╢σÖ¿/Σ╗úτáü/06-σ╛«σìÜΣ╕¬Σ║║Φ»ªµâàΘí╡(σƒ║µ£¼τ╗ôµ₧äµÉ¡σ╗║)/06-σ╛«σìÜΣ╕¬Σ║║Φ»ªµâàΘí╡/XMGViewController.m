//
//  XMGViewController.m
//  06-微博个人详情页
//
//  Created by xiaomage on 15/9/7.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGViewController.h"

@interface XMGViewController ()

@end

@implementation XMGViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // tableView里面的内容,cell,头部视图等等,他们的位置都是由系统决定,你只能决定的高度.
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 200)];
    headView.backgroundColor = [UIColor greenColor];
    
    // 设置tableView头部视图
    self.tableView.tableHeaderView = headView;
    
//    self.tableView.contentInset = UIEdgeInsetsMake(100, 0, 0, 0);
    
    // 在iOS7之后,苹果会自动给导航控制器里面的所有UIScrollView顶部都会添加额外的滚动区域64.
    
    // 设置不需要添加额外的滚动区域
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    // tableView才有这个功能,只要设置tableView顶部额外滚动区域,就会往下边挤
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
        NSLog(@"%f",self.tableView.contentInset.top);
//    NSLog(@"%@",NSStringFromCGRect(self.view.frame));
}
@end