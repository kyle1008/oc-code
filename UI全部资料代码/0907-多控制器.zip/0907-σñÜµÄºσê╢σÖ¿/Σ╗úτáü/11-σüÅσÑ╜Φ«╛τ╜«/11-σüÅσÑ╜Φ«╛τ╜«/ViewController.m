//
//  ViewController.m
//  11-偏好设置
//
//  Created by xiaomage on 15/9/7.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (IBAction)save:(id)sender {
    
    // 偏好设置存储 NSUserDefaults
    
    // 什么时候使用偏好设置存储
    // 偏好设置好处,1.快速进行键值对的存储 2.不关系文件名
    
   //  获取NSUserDefaults单例对象
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    // @"123" @"num"
    [defaults setObject:@"123" forKey:@"num"];
    // bool,int YES isOn
    [defaults setBool:YES forKey:@"isOn"];
    
    
//    NSDictionary *dict = nil;
//    dict writeToFile:<#(NSString *)#> atomically:<#(BOOL)#>
}

- (IBAction)read:(id)sender {
    
    // NSUserDefaults
   NSString *num = [[NSUserDefaults standardUserDefaults] objectForKey:@"num"];
   BOOL ison =  [[NSUserDefaults standardUserDefaults] boolForKey:@"isOn"];
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
