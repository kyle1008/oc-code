//
//  XMGViewController.m
//  06-微博个人详情页
//
//  Created by xiaomage on 15/9/7.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGViewController.h"

@interface XMGViewController ()

@end

@implementation XMGViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // tableView里面的内容,cell,头部视图等等,他们的位置都是由系统决定,你只能决定的高度.
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(2000, 2000, 0, 200)];
    headView.backgroundColor = [UIColor greenColor];
    
    // 设置tableView头部视图
    self.tableView.tableHeaderView = headView;
    
//    self.tableView.contentInset = UIEdgeInsetsMake(100, 0, 0, 0);
    
    // 在iOS7之后,苹果会自动给导航控制器里面的所有UIScrollView顶部都会添加额外的滚动区域64.
    
    // 设置不需要添加额外的滚动区域
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    // tableView才有这个功能,只要设置tableView顶部额外滚动区域,就会往下边挤
    
    // 设置导航条
    [self setUpNavigationBar];
    
  
    
}

// 设置导航条
- (void)setUpNavigationBar
{
    // 设置导航条背景为透明
    // UIBarMetricsDefault只有设置这种模式,才能设置导航条背景图片
    // 传递一个空的UIImage
    [self.navigationController.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
    // 清空导航条的阴影的线
    [self.navigationController.navigationBar setShadowImage:[[UIImage alloc] init]];
    
    // 设置导航条标题为透明
    UILabel *label = [[UILabel alloc] init];
    label.text = @"小码哥";
    
    // 设置文字的颜色
    label.textColor = [UIColor colorWithWhite:1 alpha:0];
    
    // 尺寸自适应:会自动计算文字大小
    [label sizeToFit];
    
    [self.navigationItem setTitleView:label];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
        NSLog(@"%f",self.tableView.contentInset.top);
//    NSLog(@"%@",NSStringFromCGRect(self.view.frame));
}
@end