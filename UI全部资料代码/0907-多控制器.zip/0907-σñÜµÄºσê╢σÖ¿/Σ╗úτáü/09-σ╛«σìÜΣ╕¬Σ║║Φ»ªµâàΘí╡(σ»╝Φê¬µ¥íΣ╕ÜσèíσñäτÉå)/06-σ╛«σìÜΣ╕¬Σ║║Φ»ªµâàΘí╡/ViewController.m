//
//  ViewController.m
//  06-微博个人详情页
//
//  Created by xiaomage on 15/9/7.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"


#import "UIImage+Image.h"

#define XMGHeadViewH 200

#define XMGHeadViewMinH 64

#define XMGTabBarH 44

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, assign) CGFloat oriOffsetY;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *headTopCons;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *headHeightCons;

@property (nonatomic, weak) UILabel *label;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // 设置tableView数据源和代理
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    
    // 设置导航条
    [self setUpNavigationBar];
    
    // 不需要添加额外的滚动区域
    self.automaticallyAdjustsScrollViewInsets = NO;

    // 先记录最开始偏移量
    _oriOffsetY = -(XMGHeadViewH + XMGTabBarH);
    
    // 设置tableView顶部额外滚动区域`
    self.tableView.contentInset = UIEdgeInsetsMake(XMGHeadViewH + XMGTabBarH, 0, 0, 0);
 
}

// 滚动tableView的时候就会调用

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    // 计算下tableView滚动了多少
    
    // 偏移量:tableView内容与可视范围的差值
    
    // 获取当前偏移量y值
    CGFloat curOffsetY = scrollView.contentOffset.y;
    
    // 计算偏移量的差值 == tableView滚动了多少
    // 获取当前滚动偏移量 - 最开始的偏移量(-244)
    CGFloat delta = curOffsetY - _oriOffsetY;
    
    // 计算下头部视图的高度
    CGFloat h = XMGHeadViewH - delta;
    if (h < XMGHeadViewMinH) {
        h = XMGHeadViewMinH;
    }
    
    // 修改头部视图高度,有视觉差效果
    _headHeightCons.constant = h;
    
    // 处理导航条业务逻辑
    
    // 计算透明度
    CGFloat alpha = delta / (XMGHeadViewH - XMGHeadViewMinH);
    
    if (alpha > 1) {
        alpha = 0.99;
    }
    
    // 设置导航条背景图片
    // 根据当前alpha值生成图片
    UIImage *image = [UIImage imageWithColor:[UIColor colorWithWhite:1 alpha:alpha]];
    
    [self.navigationController.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    // 设置导航条标题颜色
    _label.textColor = [UIColor colorWithWhite:0 alpha:alpha];
    
    NSLog(@"%f",alpha);
    
}

// 设置导航条
- (void)setUpNavigationBar
{
    // 设置导航条背景为透明
    // UIBarMetricsDefault只有设置这种模式,才能设置导航条背景图片
    // 传递一个空的UIImage
    [self.navigationController.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
    // 清空导航条的阴影的线
    [self.navigationController.navigationBar setShadowImage:[[UIImage alloc] init]];
    
    // 设置导航条标题为透明
    UILabel *label = [[UILabel alloc] init];
    label.text = @"小码哥";
    
    _label = label;
    
    // 设置文字的颜色
    label.textColor = [UIColor colorWithWhite:1 alpha:0];
    
    // 尺寸自适应:会自动计算文字大小
    [label sizeToFit];
    
    [self.navigationItem setTitleView:label];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
        cell.backgroundColor = [UIColor redColor];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row];
    
    
    return cell;
}


@end
