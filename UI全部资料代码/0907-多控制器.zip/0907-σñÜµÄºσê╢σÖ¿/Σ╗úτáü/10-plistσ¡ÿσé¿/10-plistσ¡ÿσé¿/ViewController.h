//
//  ViewController.h
//  10-plist存储
//
//  Created by xiaomage on 15/9/7.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

