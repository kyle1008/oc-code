//
//  ViewController.m
//  10-plist存储
//
//  Created by xiaomage on 15/9/7.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

#import "Person.h"

@interface ViewController ()

@end

@implementation ViewController

// 存储
- (IBAction)save:(id)sender {
    // Plist存储
    // 只有iOS中才有plist
    
    // plist存储本质,就是帮你生成一个Plist文件
    // 谁才能做Plist,(数组,字典)
    // plist文件注意点:plist文件不能存储自定义对象
    
    Person *p = [[Person alloc] init];
    
    NSArray *arr = @[@"123",@1];
    
    // File:文件的全路径
    // 1.先明确文件存储到哪,应用沙盒的某个文件夹中
    
    // 获取应用沙盒路径
//    NSString *homePath = NSHomeDirectory();
//    NSLog(@"%@",homePath);
    
    // 获取Caches文件夹路径
    // directory:搜索文件夹
    // domainMask:在哪个范围内搜索 NSUserDomainMask:在用户中查找
    // expandTilde: YES :在路径展开 NO:不展开路径 ~:代替沙盒路径
    NSString *cachesPath = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    
    // 拼接文件名
    NSString *filePath = [cachesPath stringByAppendingPathComponent:@"arr.plist"];
    
    
    [arr writeToFile:filePath atomically:YES];
    
}
// 读取
- (IBAction)read:(id)sender {
    NSString *cachesPath = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    
    // 拼接文件名
    NSString *filePath = [cachesPath stringByAppendingPathComponent:@"arr.plist"];
    
    // 读取:以什么形式存储就以什么形式读取
    NSArray *arr = [NSArray arrayWithContentsOfFile:filePath];
    
    NSLog(@"%@",arr);
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
