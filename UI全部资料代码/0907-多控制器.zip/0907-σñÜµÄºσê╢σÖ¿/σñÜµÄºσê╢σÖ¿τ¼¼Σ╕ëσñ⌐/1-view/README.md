# 1-控制器view的生命周期

1. 控制器的view的生命周期方法都是以view开头

2.  viewDidLoad ->  viewWillAppear ->  viewWillLayoutSubviews -> viewDidLayoutSubviews ->  viewDidAppear -> viewWillDisappear -> viewDidDisappear

3.在非ARC中viewDidUnload,经常用来清空界面上的数据

4.
