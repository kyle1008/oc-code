//
//  YZLoginAnimationView.m
//  私人通讯录
//
//  Created by yz on 15/8/15.
//  Copyright (c) 2015年 iThinker. All rights reserved.
//

#import "YZLoginAnimationView.h"

@interface YZLoginAnimationView ()

@property (nonatomic, weak) IBOutlet UIImageView *leftArm;

@property (nonatomic, weak) IBOutlet UIImageView *rightArm;

@property (nonatomic, weak) IBOutlet UIImageView *rightHand;

@property (nonatomic, weak) IBOutlet UIImageView *leftHand;

@property (nonatomic, weak) IBOutlet UIView *loginIconView
;

@property (nonatomic, assign) CGFloat offsetRX;

@property (nonatomic, assign) CGFloat offsetRY;

@property (nonatomic, assign) CGFloat offsetLX;

@property (nonatomic, assign) CGFloat offsetLY;

@end

@implementation YZLoginAnimationView

- (void)awakeFromNib
{
    [self setUp];
}

- (void)setUp
{
    _offsetRX =  CGRectGetMaxX(_loginIconView.frame) - _rightArm.frame.origin.x - _rightHand.bounds.size.width;
    _offsetRY =  CGRectGetHeight(_loginIconView.frame) - _leftArm.frame.origin.y ;
    
    _offsetLX =  - _leftArm.frame.origin.x ;
    _offsetLY =  CGRectGetHeight(_loginIconView.frame) - _leftArm.frame.origin.y ;
    
    _rightArm.transform = CGAffineTransformMakeTranslation(_offsetRX, _offsetRY);
    
    _leftArm.transform = CGAffineTransformMakeTranslation(_offsetLX, _offsetLY);
    
}
- (void)startAnim:(BOOL)isCoverEye
{
    if (isCoverEye) {
        [UIView animateWithDuration:.5 animations:^{
            
            _leftArm.transform = CGAffineTransformIdentity;
            
            _rightArm.transform = CGAffineTransformIdentity;
            
            
            CGAffineTransform transfromL = CGAffineTransformMakeTranslation(-_offsetLX, -_offsetLY + 5);
            _leftHand.transform = CGAffineTransformScale(transfromL, 0.01, 0.01);
            
            
            CGAffineTransform transfromR = CGAffineTransformMakeTranslation(-_offsetRX, -_offsetRY + 5);
            _rightHand.transform = CGAffineTransformScale(transfromR, 0.01, 0.01);
            
        }];
    }else{
        
        [UIView animateWithDuration:.5 animations:^{
            
            _rightArm.transform = CGAffineTransformMakeTranslation(_offsetRX, _offsetRY);
            
            _leftArm.transform = CGAffineTransformMakeTranslation(_offsetLX, _offsetLY);
            
            
            
            CGAffineTransform transfromL = CGAffineTransformIdentity;
            _leftHand.transform = CGAffineTransformScale(transfromL, 1, 1);
            
            
            CGAffineTransform transfromR = CGAffineTransformIdentity;
            _rightHand.transform = CGAffineTransformScale(transfromR, 1, 1);
        }];
 
    }
       
}

@end
