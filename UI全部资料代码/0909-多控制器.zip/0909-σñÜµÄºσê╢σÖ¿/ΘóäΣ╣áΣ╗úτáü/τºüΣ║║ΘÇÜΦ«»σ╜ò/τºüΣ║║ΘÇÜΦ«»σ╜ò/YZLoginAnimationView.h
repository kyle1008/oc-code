//
//  YZLoginAnimationView.h
//  私人通讯录
//
//  Created by yz on 15/8/15.
//  Copyright (c) 2015年 iThinker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZLoginAnimationView : UIView

- (void)startAnim:(BOOL)isCoverEye;

@end
