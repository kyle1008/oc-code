//
//  YZViewController.m
//  QQ主流框架
//
//  Created by yz on 14-8-27.
//  Copyright (c) 2014年 iThinker. All rights reserved.
//

#import "YZViewController.h"

@interface YZViewController ()

@end

@implementation YZViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
