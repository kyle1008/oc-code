//
//  QQ____Tests.m
//  QQ主流框架Tests
//
//  Created by yz on 14-8-27.
//  Copyright (c) 2014年 iThinker. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface QQ____Tests : XCTestCase

@end

@implementation QQ____Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
