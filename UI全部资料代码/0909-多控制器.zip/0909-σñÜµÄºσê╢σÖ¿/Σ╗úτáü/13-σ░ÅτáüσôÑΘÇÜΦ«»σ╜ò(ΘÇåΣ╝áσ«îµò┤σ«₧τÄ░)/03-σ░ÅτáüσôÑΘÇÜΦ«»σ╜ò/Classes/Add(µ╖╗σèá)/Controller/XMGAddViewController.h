//
//  XMGAddViewController.h
//  03-小码哥通讯录
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XMGAddViewController,XMGContact;

@protocol XMGAddViewControllerDelegate <NSObject>

@optional
// 通知代理,接收数据
// 什么时候通知代理,点击添加按钮的时候通知代理
- (void)addViewController:(XMGAddViewController *)addVc didAddContact:(XMGContact *)contact;

@end

@interface XMGAddViewController : UIViewController

@property (nonatomic, weak) id<XMGAddViewControllerDelegate> delegate;
//@property (nonatomic, weak) XMGContactViewController *contactVc;
@end
