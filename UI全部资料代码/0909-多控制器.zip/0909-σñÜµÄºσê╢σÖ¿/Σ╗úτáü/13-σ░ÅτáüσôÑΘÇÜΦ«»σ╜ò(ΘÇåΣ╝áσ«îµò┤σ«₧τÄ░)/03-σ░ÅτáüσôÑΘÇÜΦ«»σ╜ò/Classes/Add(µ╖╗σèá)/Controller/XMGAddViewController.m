//
//  XMGAddViewController.m
//  03-小码哥通讯录
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

// 设计思想,高聚合,低耦合

// 解决高耦合,一般采用代理
// 逆传:一般使用代理

#import "XMGAddViewController.h"



#import "XMGContact.h"

@interface XMGAddViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *phoneField;

@property (weak, nonatomic) IBOutlet UIButton *addBtn;
@end

@implementation XMGAddViewController
// 点击添加的时候调用
- (IBAction)add:(id)sender {
    
    // 把姓名,电话包装一个模型
    XMGContact *c =[XMGContact contactWithName:_nameField.text phone:_phoneField.text];

    // 通知联系人控制器接收数据
    // _delegate = contactVC
    if ([_delegate respondsToSelector:@selector(addViewController:didAddContact:)]) {
        [_delegate addViewController:self didAddContact:c];
    }
    
    // 代理没有值,设置添加控制器的delegate为联系人控制器,在联系人控制器跳转到添加控制器的时候,就拿到添加控制器给delegate赋值
    
//    // 把添加的联系人的信息(姓名,电话)传递给联系人控制器
//    _contactVc.contact = c;
    
    // _contactVc:没有值 _contactVc:只有联系人控制器才能拿到
    // 给添加控制器的contactVc
    
    
    // 回到联系人控制器
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // 及时监听文本框的输入
    [_nameField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    [_phoneField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
}
// 每次用户输入的时候改变
- (void)textChange
{
    _addBtn.enabled = _nameField.text.length && _phoneField.text.length;
    
}
@end
