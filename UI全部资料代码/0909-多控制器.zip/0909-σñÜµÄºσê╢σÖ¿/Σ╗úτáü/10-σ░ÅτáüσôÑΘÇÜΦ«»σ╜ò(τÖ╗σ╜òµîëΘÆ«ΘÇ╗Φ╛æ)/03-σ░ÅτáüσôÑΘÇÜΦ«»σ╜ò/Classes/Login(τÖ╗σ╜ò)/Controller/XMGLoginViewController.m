//
//  XMGLoginViewController.m
//  03-小码哥通讯录
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGLoginViewController.h"

#import "XMGLoginAnimView.h"

#import "XMGContactViewController.h"

#import "MBProgressHUD+XMG.h"

/*
 performSegueWithIdentifier底层实现:
 
 // 跳转到下一个(目的)控制器,执行segue
 [self performSegueWithIdentifier:@"login2Contact" sender:nil];
 // 1.根据标示符去storyboard中查找那根线,创建segue对象
 // 2.设置segue的来源控制器 segue.sourceVc = self;
 // 3.创建目的控制器,设置segue的目的控制器
 // 4.通知来源控制器,线准备好了,可以跳转,怎么通知,调用[self prepareForSegue:segue sender:nil]
 // 5.[segue perform]跳转
 
 // perform方法底层执行
 // 1.获取导航控制器 self.navigationController
 // 2.[push self.navigationController push:segue.destVc]
 */

@interface XMGLoginViewController ()<UITextFieldDelegate>
@property (nonatomic, weak) XMGLoginAnimView *animView;
@property (weak, nonatomic) IBOutlet UIView *animContentView;
@property (weak, nonatomic) IBOutlet UITextField *accountField;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UITextField *pwdField;
@property (weak, nonatomic) IBOutlet UISwitch *rmbPwdSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *autoLoginSwitch;

@end

@implementation XMGLoginViewController

// xmg 123

// 点击登录按钮的时候调用
- (IBAction)login:(id)sender {
    
    // 弹出蒙版,在登录期间,不允许用户交互
    [MBProgressHUD showMessage:@"正在登录ing..."];

    
    // 延迟1秒就会调用里面代码块的东西
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        // 隐藏蒙版
        [MBProgressHUD hideHUD];
        
        
        // 账号和密码正确的时候才需要跳转
        if ([_accountField.text isEqualToString:@"xmg"] && [_pwdField.text isEqualToString:@"123"]) {
            // 账号和密码输入正确
            [self performSegueWithIdentifier:@"login2Contact" sender:nil];
        }else{ // 账号或者密码输入错误
            
            // 提示用户账号或者密码错误
            [MBProgressHUD showError:@"账号或者密码错误"];
        }

        
    });
    
    
    
}


// 什么时候调用:执行完线,跳转之前的时候调用
// 作用:一般做一些跳转之前的准备操作,传值.
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSLog(@"%s",__func__);
}

// 记住密码开关状态改变的时候就会调用
- (IBAction)rmbPwdChange:(UISwitch *)sender {
    // 只要取消勾选记住密码,就取消勾选自动登录开头
    if (sender.on == NO) {
        [_autoLoginSwitch setOn:NO animated:YES];
    }
}

// 自动登录状态改变的时候就会调用
- (IBAction)autoLoginChange:(UISwitch *)sender {
    // 只要勾选了自动登录,勾选记住密码
    if (sender.on == YES) {
        [_rmbPwdSwitch setOn:YES animated:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    // 退出键盘
    [self.view endEditing:YES];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];

    // 创建登录动画
    XMGLoginAnimView *animView = [XMGLoginAnimView loginAnimView];
    _animView = animView;
    // 给动画的站位视图添加xib文件
    [_animContentView addSubview:animView];
    
    // 设置文本框代理,监听什么时候开始编辑
    _accountField.delegate = self;
    _pwdField.delegate = self;
    
    // 及时监听文本框的输入
    [_accountField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    [_pwdField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    
    // 主动判断
    [self textChange];
    
}
// 每次用户输入的时候改变
- (void)textChange
{
    _loginBtn.enabled = _accountField.text.length && _pwdField.text.length;

}

// 只要文本框开始编辑的时候调用
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.frame.origin.y == _accountField.frame.origin.y) { // 账号文本框
        
        // 账号文本框,睁开眼睛
        [_animView startAnim:NO];
    }else{
        // 密码文本框,闭上眼睛
        [_animView startAnim:YES];
    }
}


@end
