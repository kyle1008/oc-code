//
//  XMGLoginViewController.m
//  03-小码哥通讯录
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGLoginViewController.h"

#import "XMGLoginAnimView.h"


@interface XMGLoginViewController ()
@property (nonatomic, weak) XMGLoginAnimView *animView;
@property (weak, nonatomic) IBOutlet UIView *animContentView;

@end

@implementation XMGLoginViewController
- (IBAction)statAnim:(id)sender {
    // 0 1
    static int i = 1;
    // 让登录动画控件做动画
    [_animView startAnim:i % 2];
    i++;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    XMGLoginAnimView *animView = [XMGLoginAnimView loginAnimView];
    _animView = animView;
    // 给动画的站位视图添加xib文件
    [_animContentView addSubview:animView];
    
}



@end
