//
//  XMGEditViewController.m
//  03-小码哥通讯录
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGEditViewController.h"


#import "XMGContact.h"
@interface XMGEditViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *phoneField;
@property (weak, nonatomic) IBOutlet UIButton *saveBtn;

@end

@implementation XMGEditViewController
// 点击保存的时候调用
- (IBAction)save:(id)sender {
    
    // 更新模型
    _contact.name = _nameField.text;
    _contact.phone = _phoneField.text;
    
    // 通知联系人刷新表格
    // 发出通知
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updateContact" object:nil];
    
    // 回到联系控制器
    [self.navigationController popViewControllerAnimated:YES];
    
    
}
// 点击编辑按钮的时候调用
- (IBAction)edit:(UIBarButtonItem *)sender {
    if ([sender.title isEqualToString:@"编辑"]) {
        
        // 让文本框允许编辑
        _nameField.enabled = YES;
        _phoneField.enabled = YES;
        
        // 显示保存按钮
        _saveBtn.hidden = NO;
        
        // 让电话文本框开始编辑
        [_phoneField becomeFirstResponder];
        
        sender.title = @"取消";
    }else{ // 点击取消
        
        sender.title = @"编辑";
        
        // 把文本框的内容还原
        _nameField.text = _contact.name;
        _phoneField.text = _contact.phone;
        
        // 隐藏保存按钮
        _saveBtn.hidden = YES;
        
        // 让文本框不允许编辑
        _nameField.enabled = NO;
        _phoneField.enabled = NO;
        
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    
    // 控制器之间传值,一般在viewDidLoad中给子控件赋值
    // 给文本框赋值
    _nameField.text = _contact.name;
    _phoneField.text = _contact.phone;
    
}



@end
