//
//  Person.h
//  01-归档
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Person : NSObject<NSCoding>

@property (nonatomic, assign) int age;

@property (nonatomic, strong) NSString *name;

@end
