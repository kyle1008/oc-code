//
//  RedView.m
//  01-归档
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "RedView.h"

@implementation RedView

// 系统调用控件的这个方法帮你解析xib,stroyboard
- (id)initWithCoder:(NSCoder *)aDecoder
{
    // 什么时候调用[super initWithCoder:aDecoder]
    // 只要父类遵守了NSCoding协议,就调用
    if (self = [super initWithCoder:aDecoder]) {
        NSLog(@"%s",__func__);
    }
    return self;
}



@end
