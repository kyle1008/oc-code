//
//  ViewController.m
//  01-归档
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

#import "Person.h"

@interface ViewController ()

@end

@implementation ViewController
// 点击存储的时候调用
- (IBAction)save:(id)sender {
    
    // 存储自定义对象使用归档
    
    // 创建自定义对象
    Person *p = [[Person alloc] init];
    p.age = 18;
    p.name= @"xmg";
    
    // 获取caches文件夹
    NSString *cachesPath = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    
    // 拼接文件名
    NSString *filePath = [cachesPath stringByAppendingPathComponent:@"person.data"];
    
    // object:需要归档的对象
    // file:文件全路径
    // 任何对象都可以进行归档
    [NSKeyedArchiver archiveRootObject:p toFile:filePath];
    // 调用自定义对象的 encodeWithCoder:
    // 如果一个自定义对象需要归档,必须遵守NSCoding协议,并且实现协议的方法.
    
}
// 点击读取的时候调用
- (IBAction)read:(id)sender {
    
    // 读取文件
    // 获取caches文件夹
    NSString *cachesPath = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    
    // 拼接文件名
    NSString *filePath = [cachesPath stringByAppendingPathComponent:@"person.data"];
    
    // 存进去是什么,读取出来也是什么对象
    // 解档
    Person *p = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
    // 底层会调用自定义对象的initWithCoder
    NSLog(@"%@ %d",p.name,p.age);
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
