//
//  Person.m
//  01-归档
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "Person.h"

@implementation Person

// 什么作用:告诉系统模型中的哪些属性需要归档
// 什么时候调用:把一个自定义对象,归档的时候调用
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    // aCoder用来归档
    // name
    [aCoder encodeObject:_name forKey:@"name"];
    // age
    [aCoder encodeInt:_age forKey:@"age"];
    
}

// 什么时候调用:解析一个文件的时候调用
// 作用:告诉系统模型中的哪些属性需要解档
- (id)initWithCoder:(NSCoder *)aDecoder
{
    // [super initWithCoder]
    if (self = [super init]) {
       
        // 注意:一定要记得给成员属性赋值
        
        // name
       _name = [aDecoder decodeObjectForKey:@"name"];
        
        // age
       _age = [aDecoder decodeIntForKey:@"age"];
        
    }
    
    return self;
    
}

@end
