//
//  ViewController.m
//  02-transform
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *redView;

@end

@implementation ViewController
// 点击按钮的时候平移控件
- (IBAction)btnClick:(id)sender {
    
    [UIView animateWithDuration:0.25 animations:^{
        
//        CGRect frame = _redView.frame;
//        frame.origin.x += 200;
//        _redView.frame = frame;
        // 相对于最开始的位置平移
        // MakeTranslation:基于最开始的位置形变,每次一使用,把之前的形变清空,重新从最原始的位置形变
//        _redView.transform = CGAffineTransformMakeTranslation(200, 0);
        
        // 相对于上一次形变
        // t:相对于哪一次的形变
//        _redView.transform = CGAffineTransformTranslate(_redView.transform, 100, 0);
        
        // 旋转
//        _redView.transform = CGAffineTransformMakeRotation(M_PI_2);
        // 缩放
        // sx:宽度缩放比例, sy:高度缩放比例
//        _redView.transform = CGAffineTransformMakeScale(0.5, 0.5);
        
        _redView.transform = CGAffineTransformRotate(_redView.transform, M_PI_2);
    }];
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    // transform:所有的控件都有transform
    // transform:形变
    // transform有什么作用?设置控件形变(平移,旋转,缩放)
    
//    _redView.transform = CGAffineTransformMakeTranslation(100, 0);
    
}



@end
