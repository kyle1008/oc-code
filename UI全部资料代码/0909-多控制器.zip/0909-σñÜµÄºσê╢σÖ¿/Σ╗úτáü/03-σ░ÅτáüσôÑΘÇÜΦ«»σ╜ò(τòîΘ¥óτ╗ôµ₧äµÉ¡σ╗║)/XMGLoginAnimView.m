//
//  XMGLoginAnimView.m
//  03-小码哥通讯录
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGLoginAnimView.h"

@implementation XMGLoginAnimView

+ (instancetype)loginAnimView
{
    return [[NSBundle mainBundle] loadNibNamed:@"XMGLoginAnimView" owner:nil options:nil][0];
}
@end
