//
//  XMGContactViewController.m
//  03-小码哥通讯录
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGContactViewController.h"

@interface XMGContactViewController ()<UIActionSheetDelegate>

@end

@implementation XMGContactViewController

// 点击注销的时候调用
- (IBAction)logout:(id)sender {

    
    // UIActionSheet
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"确定要注销吗?" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"注销" otherButtonTitles:nil, nil];
    
    [sheet showInView:self.view];
    
}

// 监听UIActionSheet上按钮的点击
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        // 点击注销
        [self.navigationController popViewControllerAnimated:YES];
    }
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
   
}
@end