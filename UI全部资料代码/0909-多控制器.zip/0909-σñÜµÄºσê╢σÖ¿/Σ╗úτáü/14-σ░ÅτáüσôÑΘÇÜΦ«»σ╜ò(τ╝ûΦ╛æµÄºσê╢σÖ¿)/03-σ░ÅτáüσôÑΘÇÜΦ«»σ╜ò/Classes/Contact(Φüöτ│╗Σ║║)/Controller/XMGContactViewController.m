//
//  XMGContactViewController.m
//  03-小码哥通讯录
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGContactViewController.h"
#import "XMGAddViewController.h"

#import "XMGContact.h"
@interface XMGContactViewController ()<UIActionSheetDelegate,XMGAddViewControllerDelegate>

@property (nonatomic, strong) NSMutableArray *contacts;

@end

@implementation XMGContactViewController

- (NSMutableArray *)contacts
{
    if (_contacts == nil) {
        _contacts = [NSMutableArray array];
    }
    return _contacts;
}

/*
 逆传:代理
 1.接收方要有属性接收
 2.传递方声明代理协议和属性
 3.在接收方(来源控制器)跳转到传递方(目的控制器),给目的控制器的代理属性赋值
 4.在恰当的时候(点击添加按钮),拿到代理传值
 
 */

// 点击注销的时候调用
- (IBAction)logout:(id)sender {

    
    // UIActionSheet
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"确定要注销吗?" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"注销" otherButtonTitles:nil, nil];
    
    [sheet showInView:self.view];
    
}

// 监听UIActionSheet上按钮的点击
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        // 点击注销
        [self.navigationController popViewControllerAnimated:YES];
    }
}

// 指向segue之后,跳转之前调用
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.destinationViewController isKindOfClass:[XMGAddViewController class]]) {
        
        XMGAddViewController *addVc = segue.destinationViewController;
        addVc.delegate = self;
    }
}

// 添加一个新的联系人的时候调用
- (void)addViewController:(XMGAddViewController *)addVc didAddContact:(XMGContact *)contact
{
    NSLog(@"%@",contact.name);
    // 保存联系人
    [self.contacts addObject:contact];
    
    // 展示出来
    [self.tableView reloadData];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.contacts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:ID];
//    }
    
    // 获取模型
    XMGContact *c = self.contacts[indexPath.row];
    
    cell.textLabel.text = c.name;
    cell.detailTextLabel.text = c.phone;
    
    return cell;
}
@end