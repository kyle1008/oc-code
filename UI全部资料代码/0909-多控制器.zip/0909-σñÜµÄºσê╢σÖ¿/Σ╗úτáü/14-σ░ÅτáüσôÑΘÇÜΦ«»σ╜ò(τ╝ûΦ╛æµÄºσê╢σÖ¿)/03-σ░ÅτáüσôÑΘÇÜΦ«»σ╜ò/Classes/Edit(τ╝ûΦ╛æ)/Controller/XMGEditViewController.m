//
//  XMGEditViewController.m
//  03-小码哥通讯录
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGEditViewController.h"

@interface XMGEditViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *phoneField;
@property (weak, nonatomic) IBOutlet UIButton *saveBtn;

@end

@implementation XMGEditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 及时监听文本框的输入
    [_nameField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    [_phoneField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    
    [self textChange];
}
// 每次用户输入的时候改变
- (void)textChange
{
    _saveBtn.enabled = _nameField.text.length && _phoneField.text.length;
    
}
@end
