//
//  XMGLoginViewController.m
//  03-小码哥通讯录
//
//  Created by xiaomage on 15/9/9.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGLoginViewController.h"

#import "XMGLoginAnimView.h"


@interface XMGLoginViewController ()<UITextFieldDelegate>
@property (nonatomic, weak) XMGLoginAnimView *animView;
@property (weak, nonatomic) IBOutlet UIView *animContentView;
@property (weak, nonatomic) IBOutlet UITextField *accountField;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UITextField *pwdField;
@property (weak, nonatomic) IBOutlet UISwitch *rmbPwdSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *autoLoginSwitch;

@end

@implementation XMGLoginViewController
// 记住密码开关状态改变的时候就会调用
- (IBAction)rmbPwdChange:(UISwitch *)sender {
    // 只要取消勾选记住密码,就取消勾选自动登录开头
    if (sender.on == NO) {
        [_autoLoginSwitch setOn:NO animated:YES];
    }
}

// 自动登录状态改变的时候就会调用
- (IBAction)autoLoginChange:(UISwitch *)sender {
    // 只要勾选了自动登录,勾选记住密码
    if (sender.on == YES) {
        [_rmbPwdSwitch setOn:YES animated:YES];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];

    // 创建登录动画
    XMGLoginAnimView *animView = [XMGLoginAnimView loginAnimView];
    _animView = animView;
    // 给动画的站位视图添加xib文件
    [_animContentView addSubview:animView];
    
    // 设置文本框代理,监听什么时候开始编辑
    _accountField.delegate = self;
    _pwdField.delegate = self;
    
    // 及时监听文本框的输入
    [_accountField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    [_pwdField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    
}
// 每次用户输入的时候改变
- (void)textChange
{
    _loginBtn.enabled = _accountField.text.length && _pwdField.text.length;

}

// 只要文本框开始编辑的时候调用
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.frame.origin.y == _accountField.frame.origin.y) { // 账号文本框
        
        // 账号文本框,睁开眼睛
        [_animView startAnim:NO];
    }else{
        // 密码文本框,闭上眼睛
        [_animView startAnim:YES];
    }
}


@end
