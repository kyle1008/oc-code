//
//  ViewController.m
//  04-音乐震动条
//
//  Created by Gavin on 15/9/17.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *contentView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    
    //复制层.
    CAReplicatorLayer *repL = [CAReplicatorLayer layer];
    repL.frame = self.contentView.bounds;
    
    repL.instanceCount = 4;
    
    repL.instanceTransform = CATransform3DMakeTranslation(40, 0, 0);
    //设置动画延时执行的时间
    repL.instanceDelay = 0.5;
    
    [self.contentView.layer addSublayer:repL];
    
    
    
    //创建一个音量震动条
    CALayer *layer = [CALayer layer];
    CGFloat w = 30;
    CGFloat h = 100;
    layer.bounds = CGRectMake(0, 0, w, h);
    layer.backgroundColor = [UIColor redColor].CGColor;
    layer.anchorPoint = CGPointMake(0, 1);
    layer.position = CGPointMake(0, self.contentView.bounds.size.height);
    [repL addSublayer:layer];

    
    //添加动画
    CABasicAnimation *anim = [CABasicAnimation animation];
    anim.keyPath = @"transform.scale.y";
    anim.toValue = @0;
    anim.duration = 0.5;
    anim.repeatCount = MAXFLOAT;
    anim.autoreverses = YES;
    
    [layer addAnimation:anim forKey:nil];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
