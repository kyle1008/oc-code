//
//  VCView.h
//  07-粒子效果
//
//  Created by Gavin on 15/9/17.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VCView : UIView

//开始
- (void)start;

//重绘
- (void)reDraw;



@end
