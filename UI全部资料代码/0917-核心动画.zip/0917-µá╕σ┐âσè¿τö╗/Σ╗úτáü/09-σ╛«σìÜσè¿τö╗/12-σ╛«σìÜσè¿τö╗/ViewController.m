//
//  ViewController.m
//  12-微博动画
//
//  Created by Gavin on 15/9/17.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"
#import "ComposeVC.h"
#import "MuneItem.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)btnClick:(id)sender {
    
    ComposeVC *vc = [[ComposeVC alloc] init];
    
    MuneItem *item = [MuneItem itemWithTitle:@"点评" image:[UIImage imageNamed:@"tabbar_compose_review"]];
    MuneItem *item1 = [MuneItem itemWithTitle:@"更多" image:[UIImage imageNamed:@"tabbar_compose_more"]];
    MuneItem *item2 = [MuneItem itemWithTitle:@"拍摄" image:[UIImage imageNamed:@"tabbar_compose_camera"]];
    MuneItem *item3 = [MuneItem itemWithTitle:@"相册" image:[UIImage imageNamed:@"tabbar_compose_photo"]];
    MuneItem *item4 = [MuneItem itemWithTitle:@"文字" image:[UIImage imageNamed:@"tabbar_compose_idea"]];
    MuneItem *item5 = [MuneItem itemWithTitle:@"签到" image:[UIImage imageNamed:@"tabbar_compose_review"]];
    
    
    vc.itemArray = @[item,item1,item2,item3,item4,item5];
    

    [self presentViewController:vc animated:YES completion:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
