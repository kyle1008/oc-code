//
//  XMGDiscoverViewController.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGDiscoverViewController.h"

@interface XMGDiscoverViewController ()

@end

@implementation XMGDiscoverViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

}




@end
