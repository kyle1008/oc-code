//
//  XMGGroupBuyViewController.m
//  彩票
//
//  Created by xiaomage on 15/9/22.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGGroupBuyViewController.h"

@interface XMGGroupBuyViewController ()

@end

@implementation XMGGroupBuyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 默认按钮的图片在左边
    UIButton *titleButton = [UIButton buttonWithType:UIButtonTypeCustom];
    // 文字
    [titleButton setTitle:@"全部采种" forState:UIControlStateNormal];
    
    // image
    [titleButton setImage:[UIImage imageNamed:@"YellowDownArrow"] forState:UIControlStateNormal];
    
    // 自动计算按钮尺寸
    [titleButton sizeToFit];
    
    self.navigationItem.titleView = titleButton;
}
@end