//
//  XMGHallViewController.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGHallViewController.h"

#import "XMGCover.h"

#import "XMGPopMenu.h"

#import "UIImage+Image.h"

@interface XMGHallViewController ()<XMGPopMenuDelegate>

@end

@implementation XMGHallViewController

// 插件路径:前往 -> 资源库 -> Application Support -> Developer

- (void)viewDidLoad {
    [super viewDidLoad];
    // 创建item
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithImage:[UIImage imageWithOriginalImageName:@"CS50_activity_image"] style:0 target:self action:@selector(activity)];
    
    self.navigationItem.leftBarButtonItem = item;
}

// 点击活动按钮就会调用
- (void)activity
{
    // 1.弹出蒙版
    [XMGCover show];
    // bug:发现一个控件没有显示,1.有没有设置尺寸 2.看有没有控件挡住 3.有可能你都没有添加到某个控件
    
    CGFloat screenW = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenH = [UIScreen mainScreen].bounds.size.height;
  
    
    // 2.弹出pop菜单
   XMGPopMenu *menu = [XMGPopMenu showInPoint:CGPointMake(screenW * 0.5, screenH * 0.5)];
    menu.delegate = self;
    
}

#pragma mark - XMGPopMenuDelegate
// 点击菜单中关闭按钮就会调用
- (void)popMenuDidClickClose:(XMGPopMenu *)popMenu
{
//    [UIView animateWithDuration:0.25 animations:nil completion:^(BOOL finished) {
//        // 动画完成的时候做事情
//        
//    }];
    
    
    void (^completion)() = ^(){
        // 隐藏完成的时候,需要做事情
        
        // 移除蒙版
        [XMGCover hide];
    };
    
    // 隐藏pop菜单到某个点
    [popMenu hideInPoint:CGPointMake(44, 44) completion:completion];
    
//    [popMenu hideInPoint:CGPointMake(44, 44) completion:block];
    
}
@end
