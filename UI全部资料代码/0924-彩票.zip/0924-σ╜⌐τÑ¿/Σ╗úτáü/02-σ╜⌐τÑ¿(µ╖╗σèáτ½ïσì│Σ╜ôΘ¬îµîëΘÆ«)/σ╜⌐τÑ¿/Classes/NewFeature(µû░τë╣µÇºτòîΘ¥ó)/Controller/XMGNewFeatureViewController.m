//
//  XMGNewFeatureViewController.m
//  彩票
//
//  Created by xiaomage on 15/9/22.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGNewFeatureViewController.h"


#import "UIView+Frame.h"

#define XMGScreenW [UIScreen mainScreen].bounds.size.width

#define XMGScreenH [UIScreen mainScreen].bounds.size.height

#import "XMGNewFeatureCell.h"

@interface XMGNewFeatureViewController ()

@property (nonatomic, assign) CGFloat lastoffsetX;

@property (nonatomic, weak) UIImageView *guideView;

@end

@implementation XMGNewFeatureViewController

// 使用UICollectionViewController
// 1.必须设置一个布局参数(流水布局)
// 2.cell必须通过注册
// 3.自定义cell

- (instancetype)init
{
    // 创建流水布局
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    
    // 设置cell尺寸
    layout.itemSize = [UIScreen mainScreen].bounds.size;
    
    // 设置最小行间距 10
    layout.minimumLineSpacing = 0;
    // 设置每个cell之间间距
    layout.minimumInteritemSpacing = 0;
    // 设置每一组的间距
//    layout.sectionInset = UIEdgeInsetsMake(100, 0, 0, 0);
    // 设置滚动方向
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    return  [self initWithCollectionViewLayout:layout];
}
static NSString *ID = @"cell";
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self setUpCollectionView];
    
    // 添加所有的子控件
    [self setUpAllChildView];
    
}

#pragma UIScrollView代理
// 滚动完成的时候调用
- (void)scrollViewDidEndDecelerating:(nonnull UIScrollView *)scrollView
{
    // 获取当前偏移量
    CGFloat offsetX = scrollView.contentOffset.x;
    NSLog(@"%f", offsetX);
    
    // 计算下与之前偏移量的差值
    CGFloat delta = offsetX - _lastoffsetX;
    
    // 记录下上一次
    _lastoffsetX = offsetX;
    
    // 平移guide,largeT,largeS
    // 平移guide
    _guideView.x += 2 * delta;
    
    [UIView animateWithDuration:0.25 animations:^{
        _guideView.x -= delta;
    }];
    
}

// 添加所有的子控件
- (void)setUpAllChildView
{
    

    // guide:足球
    UIImageView *guide = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"guide1"]];
    guide.center = CGPointMake(XMGScreenW * 0.5, XMGScreenH * 0.5);
    [self.collectionView addSubview:guide];
    _guideView = guide;
    
    // 线
    UIImageView *guideLine = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"guideLine"]];
    guideLine.x -= 130;
    [self.collectionView addSubview:guideLine];

    // 大文字
    UIImageView *guideLargeT = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"guideLargeText1"]];
    guideLargeT.center = CGPointMake(XMGScreenW * 0.5, XMGScreenH * 0.8);
    [self.collectionView addSubview:guideLargeT];

    // 小文字
    UIImageView *guideLargeS = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"guideSmallText1"]];
    guideLargeS.center = CGPointMake(XMGScreenW * 0.5, XMGScreenH * 0.9);
    [self.collectionView addSubview:guideLargeS];

}

// 设置CollectionView
- (void)setUpCollectionView
{
    // 注册cell
    [self.collectionView registerClass:[XMGNewFeatureCell class] forCellWithReuseIdentifier:ID];
    // self.view != self.collectionView
    // self.collectionView 添加到 self.view
    
    self.collectionView.backgroundColor = [UIColor whiteColor];
    
    // 开启分页
    self.collectionView.pagingEnabled = YES;
    
    // 隐藏滚动条
    self.collectionView.showsHorizontalScrollIndicator = NO;
    
    // 取消弹簧效果
    self.collectionView.bounces = NO;

}

// Item:cell
// 返回collectionView中有多少个cell
- (NSInteger)collectionView:(nonnull UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 4;
}

// 返回cell外观
- (UICollectionViewCell *)collectionView:(nonnull UICollectionView *)collectionView cellForItemAtIndexPath:(nonnull NSIndexPath *)indexPath
{
  
   XMGNewFeatureCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
    // 设置cell ImageView
    NSString *imageName = [NSString stringWithFormat:@"guide%ldBackground",indexPath.row + 1];
    cell.image = [UIImage imageNamed:imageName];
    
    // 给最后一个cell添加按钮
    [cell setIndexPath:indexPath count:4];
    
    
    cell.backgroundColor = [UIColor redColor];
    
    return cell;
}

@end