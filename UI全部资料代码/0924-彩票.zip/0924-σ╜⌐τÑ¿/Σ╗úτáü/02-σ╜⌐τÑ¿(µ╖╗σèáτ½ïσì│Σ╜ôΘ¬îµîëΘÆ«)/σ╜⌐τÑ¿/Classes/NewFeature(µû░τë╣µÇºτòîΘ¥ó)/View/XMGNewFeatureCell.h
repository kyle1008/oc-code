//
//  XMGNewFeatureCell.h
//  彩票
//
//  Created by xiaomage on 15/9/22.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMGNewFeatureCell : UICollectionViewCell
@property (nonatomic, strong) UIImage *image;

// 告诉cell是不是最后一个cell
- (void)setIndexPath:(NSIndexPath *)indexPath count:(int)count;
@end
