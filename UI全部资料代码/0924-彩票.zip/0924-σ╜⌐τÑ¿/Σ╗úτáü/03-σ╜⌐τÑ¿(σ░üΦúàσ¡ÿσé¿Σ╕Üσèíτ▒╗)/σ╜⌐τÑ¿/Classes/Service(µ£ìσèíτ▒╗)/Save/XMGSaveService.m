//
//  XMGSaveService.m
//  彩票
//
//  Created by xiaomage on 15/9/24.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGSaveService.h"

@implementation XMGSaveService
+ (void)setObject:(nullable id)value forKey:(NSString *)defaultName
{
    // 有最新的版本号
    [[NSUserDefaults standardUserDefaults] setObject:value forKey:defaultName];
}

+ (nullable id)objectForKey:(NSString *)defaultName
{
   return   [[NSUserDefaults standardUserDefaults] objectForKey:defaultName];
}

@end
