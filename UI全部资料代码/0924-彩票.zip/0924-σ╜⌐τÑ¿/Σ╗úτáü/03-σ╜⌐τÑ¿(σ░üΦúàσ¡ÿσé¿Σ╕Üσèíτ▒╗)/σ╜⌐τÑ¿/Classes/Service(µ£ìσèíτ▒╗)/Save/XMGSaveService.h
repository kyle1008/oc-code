//
//  XMGSaveService.h
//  彩票
//
//  Created by xiaomage on 15/9/24.
//  Copyright © 2015年 xiaomage. All rights reserved.
//  存储业务

#import <Foundation/Foundation.h>

@interface XMGSaveService : NSObject


+ (void)setObject:(nullable id)value forKey:(NSString *)defaultName;

+ (nullable id)objectForKey:(NSString *)defaultName;


@end
