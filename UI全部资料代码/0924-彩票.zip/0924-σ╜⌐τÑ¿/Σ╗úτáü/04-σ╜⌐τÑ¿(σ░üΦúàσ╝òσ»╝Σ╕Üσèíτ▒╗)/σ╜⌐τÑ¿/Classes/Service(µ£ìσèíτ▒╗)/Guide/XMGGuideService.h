//
//  XMGGuideService.h
//  彩票
//
//  Created by xiaomage on 15/9/24.
//  Copyright © 2015年 xiaomage. All rights reserved.
//  选择窗口的根控制器,引导界面

#import <Foundation/Foundation.h>

#import <UIKit/UIKit.h>

@interface XMGGuideService : NSObject

// 选择窗口的根控制器
+ (UIViewController *)chooseWindowRootViewController;

@end
