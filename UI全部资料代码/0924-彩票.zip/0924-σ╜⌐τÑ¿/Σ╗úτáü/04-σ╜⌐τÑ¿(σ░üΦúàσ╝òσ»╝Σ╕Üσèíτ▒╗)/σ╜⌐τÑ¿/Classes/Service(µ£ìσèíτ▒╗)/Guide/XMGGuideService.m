//
//  XMGGuideService.m
//  彩票
//
//  Created by xiaomage on 15/9/24.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGGuideService.h"

#define XMGVersionKey @"version"
#import "XMGNewFeatureViewController.h"
#import "XMGTabBarController.h"
#import "XMGSaveService.h"

@implementation XMGGuideService
+ (UIViewController *)chooseWindowRootViewController
{
    // 定义一个窗口的根控制器
    UIViewController *rootVc = nil;
    
    //   获取当前的最新版本号 2.0
    NSString *curVersion =  [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
    
    // 获取上一次的版本号  1.0.1
    NSString *oldVersion = [XMGSaveService objectForKey:XMGVersionKey];
    
    if ([curVersion isEqualToString:oldVersion] == NO) {
        [XMGSaveService setObject:curVersion forKey:XMGVersionKey];
        
        XMGNewFeatureViewController *newFeatureVc = [[XMGNewFeatureViewController alloc] init];
        
        rootVc = newFeatureVc;
        
    }else{ // 没有最新的版本号
        // 进入主框架界面
        XMGTabBarController *tabBarVc = [[XMGTabBarController alloc] init];
       rootVc = tabBarVc;
        
    }
    
    return rootVc;
    
    

}
@end
