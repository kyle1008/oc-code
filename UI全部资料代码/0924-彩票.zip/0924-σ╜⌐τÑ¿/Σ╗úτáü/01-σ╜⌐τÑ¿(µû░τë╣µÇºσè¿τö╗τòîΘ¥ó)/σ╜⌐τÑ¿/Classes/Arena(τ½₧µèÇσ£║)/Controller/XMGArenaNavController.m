//
//  XMGArenaNavController.m
//  彩票
//
//  Created by xiaomage on 15/9/22.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGArenaNavController.h"

@interface XMGArenaNavController ()

@end

@implementation XMGArenaNavController
+ (void)load
{
  
    // 获取当前类下的所有导航条
   UINavigationBar *navBar = [UINavigationBar appearanceWhenContainedIn:self, nil];
    
    UIImage *image = [UIImage imageNamed:@"NLArenaNavBar64"];
    image = [image stretchableImageWithLeftCapWidth:image.size.width * 0.5 topCapHeight:image.size.height * 0.5];
    
    [navBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}



@end
