//
//  XMGArenaViewController.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGArenaViewController.h"

@interface XMGArenaViewController ()

@end

@implementation XMGArenaViewController
// 自己创建控制器的view
- (void)loadView
{
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    imageView.image = [UIImage imageNamed:@"NLArenaBackground"];
    
    imageView.userInteractionEnabled = YES;
    
    self.view = imageView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
 
    [self setNavBar];
}

- (void)setNavBar
{
    UISegmentedControl *segment = [[UISegmentedControl alloc] initWithItems:@[@"足球",@"篮球"]];
    
    segment.selectedSegmentIndex = 0;
    
    // 设置中间分割线颜色
    segment.tintColor = [UIColor greenColor];
    
    // segment:默认文字:跟选中的背景图片颜色 选中的文字颜色:白色
    // 设置选中的背景图片
    [segment setBackgroundImage:[UIImage imageNamed:@"CPArenaSegmentBG"] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [segment setBackgroundImage:[UIImage imageNamed:@"CPArenaSegmentSelectedBG"] forState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
    
    // 设置文字
    NSMutableDictionary *norAtt = [NSMutableDictionary dictionary];
    norAtt[NSForegroundColorAttributeName] = [UIColor greenColor];
    [segment setTitleTextAttributes:norAtt forState:UIControlStateNormal];
    
    // 设置选中状态的文字
    NSMutableDictionary *selAtt = [NSMutableDictionary dictionary];
    selAtt[NSForegroundColorAttributeName] = [UIColor whiteColor];
    [segment setTitleTextAttributes:selAtt forState:UIControlStateSelected];
    
    // 设置导航条的内容
    self.navigationItem.titleView = segment;
}


@end
