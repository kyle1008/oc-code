//
//  XMGTabBarButton.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGTabBarButton.h"

@implementation XMGTabBarButton
// 取消按钮高亮状态
- (void)setHighlighted:(BOOL)highlighted
{
    
}
@end
