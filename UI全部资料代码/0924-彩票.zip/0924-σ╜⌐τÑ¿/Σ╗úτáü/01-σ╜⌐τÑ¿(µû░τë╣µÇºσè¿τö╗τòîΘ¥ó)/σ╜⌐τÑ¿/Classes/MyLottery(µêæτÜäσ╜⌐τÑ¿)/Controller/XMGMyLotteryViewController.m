//
//  XMGMyLotteryViewController.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGMyLotteryViewController.h"

@interface XMGMyLotteryViewController ()

@property (weak, nonatomic) IBOutlet UIButton *loginBtn;

@end

@implementation XMGMyLotteryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
   UIImage *image =  _loginBtn.currentBackgroundImage;
    
   image = [image stretchableImageWithLeftCapWidth:image.size.width * 0.5 topCapHeight:image.size.height  * 0.5];
    
    [_loginBtn setBackgroundImage:image forState:UIControlStateNormal];
    
    // 在xib或者stroyboard中,不能直接拉伸按钮的图片,xib或者stroyboard只能拉伸UIImageView的控件
    // 按钮的背景图片只能通过代码去拉伸
}

@end
