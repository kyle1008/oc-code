//
//  AppDelegate.m
//  彩票
//
//  Created by xiaomage on 15/9/21.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "AppDelegate.h"

#import "XMGTabBarController.h"
#pragma mark - 知识点回顾
//  1.启动界面优先级: LaunchScreen > LaunchImage
//  2.app的可视尺寸由启动图片决定
//  3.LaunchScreen会自动识别设备尺寸
//  4.tabBarVc默认会把选中的控制器的添加到自己存放view子控件上
//  5.默认tabBarVc选中第一个子控制器


#define XMGVersionKey @"version"

#import "XMGNewFeatureViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

// 思想:封装思想:谁的事情交给谁管理
// 如果管理,自定义类

// 程序启动完成的时候调用
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    // 1.创建窗口
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    // 2.设置窗口的根控制器

  
    
    XMGNewFeatureViewController *newFeatureVc = [[XMGNewFeatureViewController alloc] init];
    
    self.window.rootViewController = newFeatureVc;
    
    // 新特性界面:-> 控制器
    // 显示新特性界面
    
    // 1.第一次使用app新的版本时候,会显示新特性界面
    
    // 2.如果判断下我们的app是否有新的版本号
    
    // 3.最新的版本号保存到项目的info.plist文件
    
    // 获取当前的最新版本号 1.0.1
//   NSString *curVersion =  [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
//    
//    // 获取上一次的版本号 1.0
//    NSString *oldVersion = [[NSUserDefaults standardUserDefaults] objectForKey:XMGVersionKey];
//
//    if ([curVersion isEqualToString:oldVersion] == NO) {
//        // 有最新的版本号 1.0.1
//        [[NSUserDefaults standardUserDefaults] setObject:curVersion forKey:XMGVersionKey];
//        
//        
//        // 进入新特性界面
//        NSLog(@"进入新特性界面");
//        
//    }else{ // 没有最新的版本号
//        // 进入主框架界面
////        XMGTabBarController *tabBarVc = [[XMGTabBarController alloc] init];
////        self.window.rootViewController = tabBarVc;
//        NSLog(@"进入主框架界面");
//        
//    }
    
    // 3.显示窗口
    [self.window makeKeyAndVisible];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
