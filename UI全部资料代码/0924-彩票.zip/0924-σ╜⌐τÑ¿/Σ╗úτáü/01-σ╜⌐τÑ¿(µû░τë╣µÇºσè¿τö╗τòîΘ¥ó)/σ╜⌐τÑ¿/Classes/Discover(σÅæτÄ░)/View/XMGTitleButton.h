//
//  XMGTitleButton.h
//  彩票
//
//  Created by xiaomage on 15/9/22.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMGTitleButton : UIButton

@end
