//
//  ViewController.m
//  06-注册界面
//
//  Created by xiaomage on 15/9/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *flagField;
@property (weak, nonatomic) IBOutlet UITextField *birthdayField;
@property (weak, nonatomic) IBOutlet UITextField *cityField;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // 监听国旗文本框的输入
    _flagField.delegate = self;
    _birthdayField.delegate = self;
    _cityField.delegate = self;
    
}

#pragma mark - UITextFieldDelegate

// 是否允许开始编辑
// 每次开始编辑文本框的时候,就会询问代理,是否允许开始编辑
//- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
//{
//    NSLog(@"%s",__func__);
//    return NO;;
//}

// 是否允许结束编辑
//- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
//{
//    NSLog(@"%s",__func__);
//    return NO;
//}

// 是否允许用户输入文字
// 拦截用户的输入
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    return NO;
    
}

@end
