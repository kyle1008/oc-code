//
//  ViewController.m
//  04-PickerView简单使用
//
//  Created by xiaomage on 15/9/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIPickerViewDataSource,UIPickerViewDelegate>

@property (nonatomic, strong) NSArray *foods;

@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;
@property (weak, nonatomic) IBOutlet UILabel *label;

@end

@implementation ViewController

- (NSArray *)foods
{
    if (_foods == nil) {
       NSString *filePath = [[NSBundle mainBundle] pathForResource:@"foods.plist" ofType:nil];
        _foods = [NSArray arrayWithContentsOfFile:filePath];
    }
    
    return _foods;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 数据源
    self.pickerView.dataSource = self;
    
    // 代理
    self.pickerView.delegate = self;
    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return self.foods.count;
}

// 第component有多少行
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSArray *arr = self.foods[component];
    
    return arr.count;
}

// 第component第row行标题
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSArray *arr = self.foods[component];
    
    return arr[row];
    
}

// 选中第component第row行
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSString *title = self.foods[component][row];
    
    _label.text = title;
}




@end
