//
//  _8_____________Tests.m
//  08-设置导航条的内容(掌握)Tests
//
//  Created by yz on 14-10-25.
//  Copyright (c) 2014年 iThinker. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _8_____________Tests : XCTestCase

@end

@implementation _8_____________Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
