//
//  HMOneViewController.m
//  08-设置导航条的内容(掌握)
//
//  Created by yz on 14-10-25.
//  Copyright (c) 2014年 iThinker. All rights reserved.
//

#import "OneViewController.h"

#import "TwoViewController.h"


@interface OneViewController ()

@end

@implementation OneViewController
- (IBAction)jump2Two:(id)sender {
    TwoViewController *two = [[TwoViewController alloc] init];
    
    [self.navigationController pushViewController:two animated:YES];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSLog(@"%@",[self.navigationController.view class]);
    
    self.navigationItem.title = @"第一个控制器";
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStyleBordered target:nil action:nil];
    
//    UIView *v = [[UIView alloc] init];
//    v.frame = CGRectMake(0, 2222, 20, 20);
//    v.backgroundColor = [UIColor redColor];
    
    
//    UISegmentedControl *segue = [[UISegmentedControl alloc] initWithItems:@[@"消息",@"通话"]];
//    
//    segue.selectedSegmentIndex = 0;

//    UIButton *add = [UIButton buttonWithType:UIButtonTypeContactAdd];
    
//    self.navigationItem.titleView = add;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
