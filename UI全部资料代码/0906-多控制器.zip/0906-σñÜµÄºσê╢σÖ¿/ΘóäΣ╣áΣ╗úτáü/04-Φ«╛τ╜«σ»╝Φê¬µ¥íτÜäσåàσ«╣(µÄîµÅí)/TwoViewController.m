//
//  HMTwoViewController.m
//  08-设置导航条的内容(掌握)
//
//  Created by yz on 14-10-25.
//  Copyright (c) 2014年 iThinker. All rights reserved.
//

#import "TwoViewController.h"


#import "ThreeViewController.h"

@interface TwoViewController ()

@end

@implementation TwoViewController
- (IBAction)jump2Three:(id)sender {
    ThreeViewController *three = [[ThreeViewController alloc] init];
    
    [self.navigationController pushViewController:three animated:YES];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UIBarButtonItem *left = [[UIBarButtonItem alloc] initWithTitle:@"哈哈" style:UIBarButtonItemStyleBordered target:nil action:nil];
    
    UIBarButtonItem *rigth = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"navigationbar_friendsearch"] style:UIBarButtonItemStyleBordered target:nil action:nil];
//    self.navigationItem.leftBarButtonItem = left;
    
    self.navigationItem.rightBarButtonItems = @[left,rigth];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
