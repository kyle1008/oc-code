# 03-通过storyboard加载控制器
一.UIStoryboard:帮你加载storyboard文件
```objc

    // UIStoryboard : 帮你加载storyboard文件
    // 加载storyboard文件
    // name:storyboard文件名,不需要后缀名
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];

    // 创建storyboard描述的控制器
    // instantiateInitialViewController帮你加载箭头指向的控制器
    UIViewController *vc = [storyboard instantiateInitialViewController];

    // 根据标识符创建storyboard描述的控制器
//    UIViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"org"];
```
