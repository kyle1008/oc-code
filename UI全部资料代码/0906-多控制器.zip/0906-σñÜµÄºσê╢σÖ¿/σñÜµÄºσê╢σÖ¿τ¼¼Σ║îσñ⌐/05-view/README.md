# 05-控制器的view创建
一.`loadView`

什么时候调用:`当第一次使用控制器的view的时候就会调用`

作用:`加载控制器的view,自定义控制器的view`

注意:

1.只要重写loadView,必须自己手动创建控制器的view

2.在没给_view赋值之前,不能调用self.view;


二.`loadView加载流程`

![](../Images/控制器view加载流程.png)

三.xib加载控制器的view

`init底层会调用initWithNibName:bundle:`

```objc
// 通过xib创建XMGViewController控制器的view
// 1.判断下nibName有没有值,如果有值,就会去加载nibName指定的xib
// 2.如果nibName为空,会先去查找有没有XMGView.xib,如果有就去加载
// 3.如果没有XMGView.xib,就会去加载根类名同名的xib:XMGViewController.xib
// 4.如果还没有找到,就生成一个空的view
```
四.控制器的view延迟加载

五.控制器view默认的是几乎透明的

