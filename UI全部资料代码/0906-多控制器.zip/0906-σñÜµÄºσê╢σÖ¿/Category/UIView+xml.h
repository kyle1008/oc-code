//
//  UIView+xml.h
//  06-导航控制器(代码)
//
//  Created by yz on 14-9-21.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (xml)

- (NSString *)xmlWithViewComponent;

@end
