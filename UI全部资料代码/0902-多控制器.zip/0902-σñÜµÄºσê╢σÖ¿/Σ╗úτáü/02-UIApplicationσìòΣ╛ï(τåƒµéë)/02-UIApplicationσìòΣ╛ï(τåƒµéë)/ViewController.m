//
//  ViewController.m
//  02-UIApplication单例(熟悉)
//
//  Created by xiaomage on 15/9/2.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

#import "Person.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    [[Person alloc] init];
    
    Person *p = [Person sharePerson];
    
    NSLog(@"%@",p);
    
    // 苹果单例实现
    // 1.不能外界调用alloc,一调用就崩掉,其实就是抛异常
    // 第一次调用alloc就不崩溃,其他都崩溃
    // 2.提供一个方法给外界获取单例
    // 3.内部创建一次单例,什么时候创建,程序启动的时候创建单例
    
    // 什么是单例,整个应用程序只有一份内存,并不会分配很多内存
//    UIApplication *app = [[UIApplication alloc] init];
//
//    
//    UIApplication *app1 = [[UIApplication alloc] init];
    
    // 获取单例
//    UIApplication *app = [UIApplication sharedApplication];
    
//    NSLog(@"%@",app);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
