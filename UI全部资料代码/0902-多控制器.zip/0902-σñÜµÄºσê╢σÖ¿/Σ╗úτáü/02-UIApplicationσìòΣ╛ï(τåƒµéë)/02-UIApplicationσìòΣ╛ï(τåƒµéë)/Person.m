//
//  Person.m
//  02-UIApplication单例(熟悉)
//
//  Created by xiaomage on 15/9/2.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "Person.h"

@implementation Person
// 程序启动时候创建对象

// 静态变量
static Person *_instance = nil;

// 作用:加载类
// 什么调用:每次程序一启动,就会把所有的类加载进内存
+ (void)load
{
    NSLog(@"%s",__func__);
    
   _instance = [[self alloc] init];
    
}

+ (instancetype)sharePerson
{
    return _instance;
}

+ (instancetype)alloc
{
    
    if (_instance) {
        // 标示已经分配好了,就不允许外界在分配内存
        
        // 抛异常,告诉外界不运用分配
        // 'NSInternalInconsistencyException', reason: 'There can only be one UIApplication instance.'

        // 创建异常类
        // name:异常的名称
        // reson:异常的原因
        // userInfo:异常的信息
        NSException *excp = [NSException exceptionWithName:@"NSInternalInconsistencyException" reason:@"There can only be one Person instance." userInfo:nil];
        
        // 抛异常
        [excp raise];
        
    }
    
    
    // super -> NSObject 才知道怎么分配内存
    // 调用系统默认的做法, 当重写一个方法的时候,如果不想要覆盖原来的实现,就调用super
    return [super alloc];
}

@end
