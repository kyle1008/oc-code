//
//  ViewController.m
//  09-LoadView(控制器view的创建)
//
//  Created by xiaomage on 15/9/2.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

#import "BGView.h"

@interface ViewController ()

@end

@implementation ViewController

// loadView作用:加载控制器的view
// loadView什么调用:当控制器的view第一次使用的时候就会调用
// 在开发中没有在loadView中调用[super loadView]
// 开发中什么情况使用:只要想自定义控制器的view就调用这个方法

// 底层实现:判断下有没有指定storyboard,如果有,就会帮你创建storyboard描述的控制器的view,如果没有,创建一个空的view
//- (void)loadView
//{
//    NSLog(@"%s",__func__);
//    // 调用系统的默认做法
//    [super loadView];
//}

//- (UIView *)view
//{
//    if (_view == nil) {
//        [self loadView];
//    }
//    
//    return self;
//}

// 最好不要使用view的get方法
//- (void)loadView
//{
//    BGView *view = [[BGView alloc] initWithFrame:[UIScreen mainScreen].bounds];
//    
//    self.view = view;
//    
//    self.view.backgroundColor = [UIColor redColor];
//    
//}

// 控制器的view加载完成的时候调用
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSLog(@"%@",self.view);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
