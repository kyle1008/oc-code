//
//  main.m
//  04-UIApplicationDelegate(熟悉)
//
//  Created by xiaomage on 15/9/2.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
// main -> UIApplicationMain


// UIApplicationMain底层实现
// 1.创建UIApplication
// 2.创建UIApplication代理对象,成为UIApplication代理
// 3.开启主运行循环,处理事件,可以让程序一直在运行
// 4.加载info.plist文件,判断有没有指定main.stroyboard,如果指定,就会去加载


int main(int argc, char * argv[]) {
    @autoreleasepool {

        // 第三个参数:nil => @"UIApplication",UIApplication类名字符串
        // 第四个参数:UIApplication代理的类型的名称
        
        return UIApplicationMain(argc, argv, @"UIApplication",NSStringFromClass([AppDelegate class]));
    }
        // NSStringFromClass好处
        // 1.不会写错
        // 2.有提示
}

void text(NSString *principalClassName,NSString *delegateClassName)
{
    // 字符串转换成类名
   Class UIApplicationClass =  NSClassFromString(principalClassName);
    // 1.创建UIApplication对象
    UIApplication *app = [[UIApplicationClass alloc] init];
    
    // 字符串转换成类名
    Class AppDelegateClass = NSClassFromString(delegateClassName);
    
    // 2.创建代理
   AppDelegate *appDelegate = [[AppDelegateClass alloc] init];
    
    // 设置代理
    app.delegate = appDelegate;
    
    // 3.开启循环
    while (1) {
        // 处理事件
        
    }
    
    // 加载info.plist文件
   NSString *mainStr = [NSBundle mainBundle].infoDictionary[@"UIMainStoryboardFile"];
    
    if (mainStr) {
        // 加载main.storyboard
    }
    
    
}