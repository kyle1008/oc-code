//
//  AppDelegate.m
//  04-UIApplicationDelegate(熟悉)
//
//  Created by xiaomage on 15/9/2.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()


@end

@implementation AppDelegate


// AppDelegate:监听应用程序的生命周期
// 以下方法就是应用程序的生命周期方法

// 应用程序启动完成的时候就会调用AppDelegate的方法
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    NSLog(@"%s",__func__);
    
    return YES;
    
    
}

// 当应用程序失去焦点的时候调用
- (void)applicationWillResignActive:(UIApplication *)application {
     NSLog(@"%s",__func__);
}

// 当应用程序进入后台的时候调用
- (void)applicationDidEnterBackground:(UIApplication *)application {
     NSLog(@"%s",__func__);
    
    // 保存一些信息
    
}

// 当应用程序进入前台的时候调用
- (void)applicationWillEnterForeground:(UIApplication *)application {
    NSLog(@"%s",__func__);
}

// 当应用程序完全获取焦点的时候调用
// 只有当应用程序完全获取焦点的时候,才能够与用户交互
- (void)applicationDidBecomeActive:(UIApplication *)application {
     NSLog(@"%s",__func__);
}

// 当应用程序关闭的时候
- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
