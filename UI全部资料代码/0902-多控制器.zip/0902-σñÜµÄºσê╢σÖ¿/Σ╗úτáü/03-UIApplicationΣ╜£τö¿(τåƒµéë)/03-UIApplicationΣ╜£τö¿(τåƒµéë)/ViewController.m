//
//  ViewController.m
//  03-UIApplication作用(熟悉)
//
//  Created by xiaomage on 15/9/2.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
- (IBAction)btnClick:(id)sender {
    
    UIApplication *app = [UIApplication sharedApplication];
    
    // 3.设置状态栏
    // 在iOS7之后,状态栏默认交给控制器的管理
    //    app.statusBarHidden = YES;
//    [app setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
    
    
    // 4.打开网页
    // URL:资源的唯一标示符
    // http://www.baidu.com
    // URL:协议头://资源路径
    // 根据协议头判断用什么软件打开
    
    
    // 创建URL
    NSURL *url = [NSURL URLWithString:@"http://www.baidu.com"];
    
    [app openURL:url];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    // 0. 获取应用程序的象征
    UIApplication *app = [UIApplication sharedApplication];
    
    // 1.设置应用程序图标的提醒数字
    app.applicationIconBadgeNumber = 10;
    
    // 创建通知对象
    UIUserNotificationSettings *setting = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeBadge categories:nil];
    
    // 注册用户通知
    [app registerUserNotificationSettings:setting];
    
    // 2.设置联网的提示
    app.networkActivityIndicatorVisible = YES;
    
//    // 3.设置状态栏
//    // 在iOS7之后,状态栏默认交给控制器的管理
////    app.statusBarHidden = YES;
//    [app setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
    
    // 4.打电话,发短信,打开网页
}


// 隐藏状态栏
//- (BOOL)prefersStatusBarHidden
//{
//    return YES;
//}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
