//
//  AppDelegate.m
//  05-UIWindow(掌握)
//
//  Created by xiaomage on 15/9/2.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()


@end

@implementation AppDelegate

// 加载info.plist,并且做判断,判断完没有main,就不会帮你创建窗口,自己手动创建
// 程序启动完成的时候调用
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    // 窗口显示注意点:1.不要让窗口销毁,需要弄一个强引用 2.必须要设置窗口的尺寸
    // 1.创建窗口的对象
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    self.window.backgroundColor = [UIColor redColor];
    
    
    // 2.创建窗口的跟控制器,并且赋值
    // 苹果推荐使用控制器的原因,对应界面的事情交给对应的控制器去管理
    UIViewController *rootVc = [[UIViewController alloc] init];
    
    rootVc.view.backgroundColor = [UIColor greenColor];
    
    // 一旦设置窗口的根控制器,就会把根控制器的view添加到窗口
    // 做了旋转功能
    self.window.rootViewController = rootVc;
    
//    UIButton *btn = [UIButton buttonWithType:UIButtonTypeContactAdd];
//    btn.center = CGPointMake(50, 50);
//    [rootVc.view addSubview:btn];
//    [self.window addSubview:rootVc.view];
    
    // 3.显示窗口
    // 1.可以显示窗口 self.window.hidden = NO;
    // 2.成为应用程序的主窗口  application.keyWindow = self.window;

    [self.window makeKeyAndVisible];
    
    
//
//    NSLog(@"%@",self.window);
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
