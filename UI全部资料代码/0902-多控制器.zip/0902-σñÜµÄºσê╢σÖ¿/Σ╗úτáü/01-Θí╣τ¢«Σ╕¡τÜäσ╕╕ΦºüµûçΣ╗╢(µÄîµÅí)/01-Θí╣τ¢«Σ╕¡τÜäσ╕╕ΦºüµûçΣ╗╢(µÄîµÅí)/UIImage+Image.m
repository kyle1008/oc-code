//
//  UIImage+Image.m
//  01-项目中的常见文件(掌握)
//
//  Created by xiaomage on 15/9/2.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "UIImage+Image.h"

@implementation UIImage (Image)

@end
