//
//  ViewController.m
//  01-项目中的常见文件(掌握)
//
//  Created by xiaomage on 15/9/2.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"



@interface ViewController ()

@end

@implementation ViewController

// xcode6和xcode5区别
// 1.xcode6没有Frameworks,而且xcode6会自动导入常见的开发框架
// 2.xcode6比xcode5多了一个LaunchScreen.xib
// 3.在iOS开发中,app的可见范围是由启动界面决定,如果没有设置启动界面,默认可视范围是3.5inch(320 * 480),如果设置了,就会自动自动识别当前模拟器的可视范围
// 4.xcode6比xcode5少了一个pch文件

- (void)viewDidLoad {
    [super viewDidLoad];
    
//  NSLog(@"%s %d",__func__,1);
    
    XMGLog(@"%s",__func__);
    // NSLog(__VA_ARGS__)
    
    
    ABC;
    
//    [UIImage imageTest];
    
    // File:获取文件的全路径 => 文件在哪(主bundle)
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"Info.plist" ofType:nil];
    
    // 1.解析info,plist
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:filePath];
    
     // 获取当前的版本号
    NSString *Verision = dict[@"CFBundleShortVersionString"];
    
    // 第二种方式获取info.plist信息
     Verision = [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
    
    XMGLog(@"%@",Verision);
//    NSLog(@"%@",Verision);
    
}


@end
