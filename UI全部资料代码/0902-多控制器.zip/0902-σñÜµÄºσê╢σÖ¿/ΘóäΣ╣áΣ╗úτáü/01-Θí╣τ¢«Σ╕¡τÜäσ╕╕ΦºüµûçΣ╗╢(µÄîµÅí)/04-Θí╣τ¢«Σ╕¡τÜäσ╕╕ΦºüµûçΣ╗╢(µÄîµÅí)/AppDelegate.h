//
//  AppDelegate.h
//  04-项目中的常见文件(掌握)
//
//  Created by yz on 14-10-23.
//  Copyright (c) 2014年 iThinker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
