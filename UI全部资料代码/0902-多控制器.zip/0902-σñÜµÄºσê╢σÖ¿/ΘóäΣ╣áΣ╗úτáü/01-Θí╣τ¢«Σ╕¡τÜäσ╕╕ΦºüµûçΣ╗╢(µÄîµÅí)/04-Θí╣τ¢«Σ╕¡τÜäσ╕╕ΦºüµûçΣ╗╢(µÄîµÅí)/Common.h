#define A 10

