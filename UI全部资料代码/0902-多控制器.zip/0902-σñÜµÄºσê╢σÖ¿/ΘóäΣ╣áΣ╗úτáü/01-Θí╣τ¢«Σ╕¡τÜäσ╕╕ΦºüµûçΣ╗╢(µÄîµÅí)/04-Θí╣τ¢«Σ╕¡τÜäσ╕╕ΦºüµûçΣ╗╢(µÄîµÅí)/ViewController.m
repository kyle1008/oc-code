//
//  HMViewController.m
//  04-项目中的常见文件(掌握)
//
//  Created by yz on 14-10-23.
//  Copyright (c) 2014年 iThinker. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    NSDictionary *infoDict =  [NSBundle mainBundle].infoDictionary;
    
    NSString *version = infoDict[@"CFBundleVersion"];
    
//    NSLog(@"%@",version);
    HMLog(@"%@",version);
    /*
        调试阶段：编写代码，调试错误
     
        发布阶段：把程序打包成ipa,上传到appstroy,安装到用户上,不需要调试错误.
     
     */
    
    
   
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
