//
//  ViewController.m
//  图片截屏
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//

/*
    1.首先要弄一个控件把图片给展示出画
        
    2.画图分析  手指点到哪里,确定起始点
        PPT演示两个点生成的矩形
        矩形的起始点就是手指一触摸到屏幕时的位置
        矩形的结束点就是手指移动到某一个点的位置
        
        矩形的宽度等于结束点的x减去起始点的x
        矩形的高度等于结束点的y减去起始点的Y
    3. 先画上面的矩形
        3.1 利用StoryBoard给图片添加手势
            把手势拖到ImageView上面,连线,坚挺拖动事件,
            测试有没有响应拖动事件
            运行:拖动,没有反应
            原因:UIImageView默认不响应事件.
            解决办法:把UIImageView设置为允许用户交互
 
        3.2 在拖动事件方法中进行判断
         if (sender.state == UIGestureRecognizerStateBegan) {
 
               这个方法是获取手指的偏移量,不能用这个方法
               CGPoint transP = [sender translationInView:sender.view];
 
               获取当前手指的触摸点
               _startP = [sender locationInView:sender.view];
               @property(nonatomic,assign) CGPoint startP;
               让start成为成员变量的目的就是让它在下面也能够访问,因为下面要计算拖动时的偏移量
 
         }else if (sender.state == UIGestureRecognizerStateChanged){
         
            CGPoint endP = [sender locationInView:sender.view];
             确定矩形的大小
             矩形的宽度等于结束点的x减去起始点的x
             矩形的高度等于结束点的y减去起始点的Y
            CGRect clipRect = CGRectMake(_startP.x, _startP.y, endP.x - _startP.x,endP.y - _startP.y);
             
            创建蒙板View能不能在这里面写?不能
            原因:蒙板View起始至终,蒙板View之要有一个,如果在这个里面创建,这个方法会经常调,每移动一下就调用一次,就会创建一次
                想要保证只有一个,所以不能在这个里面写.
            解决办法:采用懒加载,如果有了, 我就不去创建
                @property(nonatomic,weak) UIView *cover;
            在这里只要设置蒙板的Frame就行了
            必须得要用self.cover.frame,才会调用Get方法
            self.cover.frame = clipRect;
 
         }
         懒加载View
         -(UIView *)cover{
         if (_cover == nil) {
             UIView *cover = [[UIView alloc] init];
             cover.backgroundColor = [UIColor blackColor];
             cover.alpha  = 0.7;
             还要把它加到控制器的view上面,让它显示出来
             [self.view addSubview:cover];
             _cover = cover;
         }
             return _cover;
         }
 
        3.3,手指抬起的时候,开始裁剪图片
 
         UIImageView *imageView = (UIImageView *)sender.view;
         裁剪图片
         裁剪多大的上下文?
         根图片的尺寸一样大,裁剪矩形框的区域,裁剪完毕之后, 它会把超出区域的内容全部裁剪掉
         其它部分都是透明白,看不到
         UIGraphicsBeginImageContextWithOptions(sender.view.bounds.size, NO, 0);
         绘制路径
         UIBezierPath *path = [UIBezierPath bezierPathWithRect:self.cover.frame];
         添加裁剪区域
         [path addClip];
         获取上下文
         CGContextRef ctx = UIGraphicsGetCurrentContext();
         将图片绘制到上下文
         [sender.view.layer renderInContext:ctx];
         从上下文中取出图片
         UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
         imageView.image = image;
         关闭上下文
         UIGraphicsEndImageContext();
         将蒙板从父控件中移除
         [self.cover removeFromSuperview];
         self.cover = nil;
 */


#import "ViewController.h"

@interface ViewController ()
@property(nonatomic,assign) CGPoint startP;

@property(nonatomic,weak) UIView *cover;


@end

@implementation ViewController

-(UIView *)cover{
    
    if (_cover == nil) {
        UIView *cover = [[UIView alloc] init];
        cover.backgroundColor = [UIColor blackColor];
        cover.alpha  = 0.7;
        //还要把它加到控制器的view上面,让它显示出来
        [self.view addSubview:cover];
        _cover = cover;
    }
    return _cover;
}



- (IBAction)pan:(UIPanGestureRecognizer *)sender {
    
    UIImageView *imageView = (UIImageView *)sender.view;
    
    if (sender.state == UIGestureRecognizerStateBegan) {
        //获取手指的偏移量
//        CGPoint transP = [sender translationInView:sender.view];
        //获取当前手指的触摸点
        //让start成为成员变量的目的就是让它在下面也能够访问
        _startP = [sender locationInView:sender.view];
    }else if (sender.state == UIGestureRecognizerStateChanged){
        
        CGPoint endP = [sender locationInView:sender.view];
        CGRect clipRect = CGRectMake(_startP.x, _startP.y, endP.x - _startP.x,endP.y - _startP.y);
        
        self.cover.frame = clipRect;
    }else if(sender.state == UIGestureRecognizerStateEnded){
    
        
        //裁剪图片
        //裁剪多大的上下文?
        //根图片的尺寸一样大,裁剪矩形框的区域,裁剪完毕之后, 它会把超出区域的内容全部裁剪掉
        //其它部分都是透明白,看不到
        UIGraphicsBeginImageContextWithOptions(sender.view.bounds.size, NO, 0);
        //绘制路径
        UIBezierPath *path = [UIBezierPath bezierPathWithRect:self.cover.frame];
        //添加裁剪区域
        [path addClip];
        
        //获取上下文
        CGContextRef ctx = UIGraphicsGetCurrentContext();
        //将图片绘制到上下文'
        [sender.view.layer renderInContext:ctx];
        //从上下文中取出图片
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        
        imageView.image = image;
        
        //关闭上下文
        UIGraphicsEndImageContext();
        
        //将蒙板从父控件中移除
        [self.cover removeFromSuperview];
        self.cover = nil;
        
    }
    
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
