//
//  ViewController.m
//  截屏
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//
/*
    1.介绍PPT 说明什么时候会用到截屏功能
    2.需求:当一点击屏幕的时候,就把当前控制给截屏
    3.在屏幕点击时调用
     获得位图上 下文
     UIGraphicsBeginImageContextWithOptions(view.bounds.size, NO, 0);
     获取当前的上下文
     CGContextRef ctx =  UIGraphicsGetCurrentContext();
     view之所以能显示内容,是因为有图层,因此只要把图层画到上下文
     图层只能渲染,不能绘制
     [view.layer renderInContext:ctx];
     从上下文取出图片
     UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
     关闭上下文
     UIGraphicsEndImageContext();
    4.把生成的图片写入到桌面
    5.验证图层只能够渲染
      [view.layer drawInContext:ctx];
 
 */


#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(nonnull NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
    
    NSLog(@"asdfa");
    
//    //开启一个位图上下文
//    UIGraphicsBeginImageContextWithOptions(self.view.bounds.size, NO, 0);
//   
//    //获取当前的上下文
//    CGContextRef ctx =  UIGraphicsGetCurrentContext();
//    
//    [self.view.layer renderInContext:ctx];
//    
//    //从上下文取出图片
//    
//    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
//    
//    //关闭上下文
//    UIGraphicsEndImageContext();
    
    
    NSData *data = UIImagePNGRepresentation([self captureView:self.view]);
    [data writeToFile:@"/Users/gaoxinqiang/Desktop/view4.png" atomically:YES];
    
}




- (UIImage *)captureView:(UIView *)view{
    
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, NO, 0);
    //获取当前的上下文
    CGContextRef ctx =  UIGraphicsGetCurrentContext();
    
    [view.layer renderInContext:ctx];

    //从上下文取出图片
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    //关闭上下文
    UIGraphicsEndImageContext();
    
    return image;
    
}




//
//-(void)touchesBegan:(nonnull NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
//
//    
//    //开启一个位图上下文
//    UIGraphicsBeginImageContextWithOptions(self.view.bounds.size, NO, 0);
//    //获取自己创建的位图上下文
//    CGContextRef ctx = UIGraphicsGetCurrentContext();
//    //view之所以能显示内容,是因为有图层,因此只要把图层画到上下文上就行
//    //图层这能渲染,不能绘制
//    [self.view.layer renderInContext:ctx];
//    
//    //从上下文中生成一张新的图片
//    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
//    
//    NSData *data = UIImagePNGRepresentation(image);
//    [data writeToFile:@"/Users/gaoxinqiang/Desktop/view.png" atomically:YES];
//
//    
//    
//}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
