//
//  UIImage+image.m
//  裁剪图片
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import "UIImage+image.h"

@implementation UIImage (image)

+ (UIImage *)imageWithCircleBorderWH:(CGFloat)borderWH borderColor:(UIColor *)borderColor image:(UIImage *)image{
    
    CGFloat borderW = borderWH;
    CGFloat  rectWH = image.size.width + 2 * borderW;
    CGRect rect = CGRectMake(0, 0, rectWH, rectWH);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
    //绘制外面的一大圆
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:rect];
    [borderColor set];
    [path fill];
    
    //绘制里面的小圆
    CGFloat imageWH = image.size.width;
    CGRect clipRect = CGRectMake(borderW, borderW, imageWH, imageWH);
    path = [UIBezierPath bezierPathWithOvalInRect:clipRect];
    [path fill];
    //添加裁剪区域
    [path addClip];
    //把图片绘制的图形上下文
    [image drawInRect:clipRect];
    
    //获取图片
    image = UIGraphicsGetImageFromCurrentImageContext();
    
    //关闭上下文
    UIGraphicsEndImageContext();
    
    return image;
}


@end
