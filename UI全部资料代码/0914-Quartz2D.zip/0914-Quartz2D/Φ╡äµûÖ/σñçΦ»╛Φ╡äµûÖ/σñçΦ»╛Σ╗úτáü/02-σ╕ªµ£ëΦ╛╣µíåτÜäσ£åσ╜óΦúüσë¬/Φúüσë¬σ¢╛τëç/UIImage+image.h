//
//  UIImage+image.h
//  裁剪图片
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (image)

+ (UIImage *)imageWithCircleBorderWH:(CGFloat)borderWH borderColor:(UIColor *)borderColor image:(UIImage *)image;


@end
