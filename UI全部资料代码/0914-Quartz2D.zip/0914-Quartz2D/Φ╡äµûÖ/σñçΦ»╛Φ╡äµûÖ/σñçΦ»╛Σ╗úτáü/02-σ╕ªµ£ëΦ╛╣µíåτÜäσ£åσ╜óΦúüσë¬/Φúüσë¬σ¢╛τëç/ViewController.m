//
//  ViewController.m
//  裁剪图片
//
//  Created by Gavin on 15/7/29.
//  Copyright © 2015年 Gavin. All rights reserved.
//
/*
    1.PPT分析思路
        把图片拖入到PPT,开启一个和图片一样大的上下文,才不会把图片给拉伸,
        裁剪图片, 先设置裁剪区域,再进行绘制
        裁剪一个圆, 这个圆,正切于图片,它的两倍的半径刚好等于宽高.
        再把图片画上去,超出裁剪区域的会自动裁剪掉
    2.新建工程,导入素材,简单的图片裁剪
        导入要裁剪的图片
        UIImage *image = [UIImage imageNamed:@"阿狸头像"];
        开启位图上下文
        位图上下文的大小和导入的图片大小一样,为了是不让图片拉伸
        UIGraphicsBeginImageContextWithOptions(CGSizeMake(image.size.width, image.size.height),   NO, 0);
         绘制圆形裁剪区域  裁剪区域的大小等于图片的尺寸
         UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
         让绘制的路径成为裁剪区域,超出裁剪区域的内容会自动裁剪掉
         [path addClip];
         把导入的图片画到位图上下文
         [image drawAtPoint:CGPointZero];
         从位图上下文中取出图片
         image =  UIGraphicsGetImageFromCurrentImageContext();
         _imageV.image = image;
         关闭图形上下文
         UIGraphicsEndImageContext();
 
    3. 带有边框的圆形图片
        PPT讲解思路
        1开启一下比头想大一点的上下文,
        2.画一个大圆在上面.大圆的颜色就是边框的颜色
        3.再去设置它的圆形裁剪区域
        4.再把图片画到上下文上面
 
        上下文的尺寸有多大?
        要看下你的边框宽度有多宽,确定边框宽度之后,
        在原来图片的宽高都要加上两倍的边框宽度
 
         UIImage *image = [UIImage imageNamed:@"阿狸头像"];
         边框的宽度
         CGFloat borderW = 2;
         最外面的大圆的尺寸   它等于导入图片在宽度 + 2倍的边框宽度
         CGFloat  rectWH = image.size.width + 2 * borderW;
         CGRect rect = CGRectMake(0, 0, rectWH, rectWH);
         开启一个尺寸为 rectWH的位置上下文
         UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
         绘制外面的一大圆
         UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:rect];
         设置外面大圆的颜色,也就是边框的颜色
         [[UIColor redColor] set];
         [path fill];
         
         绘制里面的小圆
         CGFloat imageWH = image.size.width;
         里面小圆的x,y位置分别是边框的宽度
         CGRect clipRect = CGRectMake(borderW, borderW, imageWH, imageWH);
         path = [UIBezierPath bezierPathWithOvalInRect:clipRect];
         [path fill];
         添加裁剪区域
         [path addClip];
         把图片绘制的图形上下文
         [image drawInRect:clipRect];
         获取图片
         image = UIGraphicsGetImageFromCurrentImageContext();
         关闭上下文
         UIGraphicsEndImageContext();
         _imageV.image = image;
 
    4.抽出一个分类
        抽分类的原因:
        是不是这些代码不经常用,很容易就忘掉了,可以把它抽出一个分类.
        以后你要做一个圆球, 你就调用这个分类就好了.这些代码没有必要去记,不常用,肯定会忘.
 
        给谁添加分类?
        这里是生成图片,是不是要给UIImage生成分类.
 
        设计分类的方法,
        可以先在外面进行设计,
 
 
 
 */



#import "ViewController.h"
#import "UIImage+image.h"
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

//    UIImage *image = [UIImage imageNamed:@"阿狸头像"];
//    CGFloat borderW = 2;
//    CGFloat  rectWH = image.size.width + 2 * borderW;
//    CGRect rect = CGRectMake(0, 0, rectWH, rectWH);
//    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
//    //绘制外面的一大圆
//    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:rect];
//    [[UIColor redColor] set];
//    [path fill];
//    
//    //绘制里面的小圆
//    CGFloat imageWH = image.size.width;
//    CGRect clipRect = CGRectMake(borderW, borderW, imageWH, imageWH);
//     path = [UIBezierPath bezierPathWithOvalInRect:clipRect];
//    [path fill];
//    //添加裁剪区域
//    [path addClip];
//    //把图片绘制的图形上下文
//    [image drawInRect:clipRect];
//    
//    //获取图片
//    image = UIGraphicsGetImageFromCurrentImageContext();
//    
//    //关闭上下文
//    UIGraphicsEndImageContext();

//    _imageV.image = [self imageWithCirclecolor:[UIColor greenColor] Image:[UIImage imageNamed:@"阿狸头像"] borderWH:3];
    
    _imageV.image = [self imageWithCircleBorderWH:5 borderColor:[UIColor redColor] image:[UIImage imageNamed:@"阿狸头像"]];

}



- (UIImage *)imageWithCircleBorderWH:(CGFloat)borderWH borderColor:(UIColor *)borderColor image:(UIImage *)image{
    
        CGFloat borderW = borderWH;
        CGFloat  rectWH = image.size.width + 2 * borderW;
        CGRect rect = CGRectMake(0, 0, rectWH, rectWH);
        UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
        //绘制外面的一大圆
        UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:rect];
        [borderColor set];
        [path fill];
    
        //绘制里面的小圆
        CGFloat imageWH = image.size.width;
        CGRect clipRect = CGRectMake(borderW, borderW, imageWH, imageWH);
         path = [UIBezierPath bezierPathWithOvalInRect:clipRect];
        [path fill];
        //添加裁剪区域
        [path addClip];
        //把图片绘制的图形上下文
        [image drawInRect:clipRect];
    
        //获取图片
        image = UIGraphicsGetImageFromCurrentImageContext();
        
        //关闭上下文
        UIGraphicsEndImageContext();
    
    return image;
}


- (void)simpleClips{

    // Do any additional setup after loading the view, typically from a nib.
    UIImage *image = [UIImage imageNamed:@"阿狸头像"];
    //     开启位图上下文
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(image.size.width, image.size.height), NO, 0);
    //绘制裁剪区域
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
    
    //让绘制的路径成为裁剪区域
    [path addClip];
    //把导入的图片画到位图上下文
    [image drawAtPoint:CGPointZero];
    
    //从位图上下文中取出图片
    image =  UIGraphicsGetImageFromCurrentImageContext();
    _imageV.image = image;
    //关闭图形上下文
    UIGraphicsEndImageContext();
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
