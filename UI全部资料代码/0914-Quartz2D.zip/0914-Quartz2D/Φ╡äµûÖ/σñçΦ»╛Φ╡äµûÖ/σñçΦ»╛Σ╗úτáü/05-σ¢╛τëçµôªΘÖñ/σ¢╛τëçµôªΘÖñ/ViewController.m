//
//  ViewController.m
//  图片擦除
//
//  Created by Gavin on 15/7/30.
//  Copyright © 2015年 Gavin. All rights reserved.
//

/*
    1.分析:其实就是两张图片,一个在上面, 一个在下面 把上面的擦出掉,透明显示下面的图片
    2.搭建界面,弄两个ImageView,一个在上面, 一个在下面
    3.给上面的图片添加一个手势
    4.确定擦出范围
     确定擦出范围
     CGFloat rectHW = 30;
     x = 手指移动的中心点 -  宽高的一半
     y = 手指移动的中心点 -  宽高的一半
 
 
     CGRect rect = CGRectMake(curP.x - rectHW * 0.5 , curP.y - rectHW * 0.5, rectHW, rectHW);
     开启图片上下文
     开启图片上下文,
     上下文的尺寸应该和最上面的一张图片大小一样.要擦除的范围和图片的尺寸一样大
     UIGraphicsBeginImageContextWithOptions(_imageV.bounds.size , NO, 0);
     将上面一张图片的内容绘制到上下文
     CGContextRef ctx = UIGraphicsGetCurrentContext();
     [_imageV.layer renderInContext:ctx];
     擦除
     CGContextClearRect(ctx, rect);
     
     从上下文中取出图片
     UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
     _imageV.image = image;
     
     关闭图形上下文
     UIGraphicsEndImageContext();

 */



#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
    [_imageV addGestureRecognizer:pan];
    
}



- (void)pan:(UIPanGestureRecognizer *)pan{
    
    //获取当前手指在图片上的位置
    CGPoint curP = [pan locationInView:_imageV];
    //确定擦出范围
    CGFloat rectHW = 30;
    //x = 手指移动的中心点 -  宽高的一半
    //y = 手指移动的中心点 -  宽高的一半
    CGRect rect = CGRectMake(curP.x - rectHW * 0.5 , curP.y - rectHW * 0.5, rectHW, rectHW);
    //开启图片上下文
    //开启图片上下文,
    UIGraphicsBeginImageContextWithOptions(_imageV.bounds.size , NO, 0);
    //将上面一张图片的内容绘制到上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    [_imageV.layer renderInContext:ctx];
    //擦除
    CGContextClearRect(ctx, rect);
    
    //从上下文中取出图片
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    _imageV.image = image;
    
    //关闭图形上下文
    UIGraphicsEndImageContext();

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
