//
//  main.m
//  图片擦除
//
//  Created by Gavin on 15/7/30.
//  Copyright © 2015年 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
