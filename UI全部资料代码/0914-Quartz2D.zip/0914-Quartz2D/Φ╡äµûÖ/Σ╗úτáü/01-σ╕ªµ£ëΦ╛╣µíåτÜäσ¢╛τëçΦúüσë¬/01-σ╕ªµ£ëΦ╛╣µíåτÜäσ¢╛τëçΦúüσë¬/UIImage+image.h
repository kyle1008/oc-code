//
//  UIImage+image.h
//  01-带有边框的图片裁剪
//
//  Created by Gavin on 15/9/14.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (image)

//给图片设置边框
//borderW:边框宽度
//borderColor:边框颜色
//image:要设置边框的图片.
+ (UIImage *)imageWithBorderWidth:(CGFloat)borderW borderColor:(UIColor *)color image:(UIImage *)image;
@end
