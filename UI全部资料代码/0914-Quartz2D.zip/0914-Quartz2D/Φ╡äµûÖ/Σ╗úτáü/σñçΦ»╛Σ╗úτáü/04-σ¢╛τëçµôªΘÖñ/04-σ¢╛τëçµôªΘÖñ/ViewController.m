//
//  ViewController.m
//  04-图片擦除
//
//  Created by Gavin on 15/9/13.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //添加手势
    self.imageV.userInteractionEnabled = YES;
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
    [self.imageV addGestureRecognizer:pan];
    
    
}


- (void)pan:(UIPanGestureRecognizer *)pan{

    //获取当前手指的点.
    CGPoint curP =  [pan locationInView:self.imageV];
    //确定擦除区域
    CGFloat rectWH = 40;
    CGRect rect = CGRectMake(curP.x - rectWH * 0.5, curP.y -  rectWH * 0.5, rectWH, rectWH);
    
    //开启一个跟ImageV相同尺寸大小的上下文.
    UIGraphicsBeginImageContextWithOptions(self.imageV.bounds.size, NO, 0);
    //获取当前的上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    //把图片绘制到上下文.
    [self.imageV.layer renderInContext:ctx];
    //确定擦除区域
    CGContextClearRect(ctx, rect);
    
    //从上下文当中取出图片
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    self.imageV.image = newImage;
    
    //关闭上下文
    UIGraphicsEndImageContext();

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
