//
//  ViewController.h
//  03-图片截屏
//
//  Created by Gavin on 15/9/13.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

