//
//  ViewController.m
//  04-图片擦除
//
//  Created by Gavin on 15/9/14.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.imageV.userInteractionEnabled = YES;
    //添加手势
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
    [self.imageV addGestureRecognizer:pan];
}


- (void)pan:(UIPanGestureRecognizer *)pan{

    //获取当前手指所在的点
    CGPoint curP = [pan locationInView:self.imageV];
    CGFloat rectWH = 50;
    CGFloat x = curP.x - rectWH * 0.5;
    CGFloat y = curP.y - rectWH * 0.5;
    CGRect rect =   CGRectMake(x, y, rectWH, rectWH);
    
    //开启一个图片上下文.
    UIGraphicsBeginImageContextWithOptions(self.imageV.bounds.size, NO, 0);
    
    //获取当前的上下文.
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    //把UImageViwe上面的图片给绘制到上下文.
    [self.imageV.layer renderInContext:ctx];
    
    //确定擦除区域
    CGContextClearRect(ctx, rect);
    
    //生成一张新图片
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    //把上下文给关闭
    UIGraphicsEndImageContext();
    //给原来图片重新赋值
    self.imageV.image = newImage;
    

    


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
