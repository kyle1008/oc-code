// C语言程序是由很多"程序段"组成的

#include <stdio.h> // 告诉系统printf函数在什么地方

/*
int call()
{
    return 0;
}
 */

// command + b 将代码翻译为计算机能够识别的语言(0/1)
// command + r 在xcode中运行程序
int main()
{
    // \n让输出的内容换行, 固定格式
    printf("hello world\n"); // 调用系统函数
    return 0;
}