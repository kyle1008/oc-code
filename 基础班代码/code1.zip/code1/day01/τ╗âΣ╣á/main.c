//
//  main.c
//  练习
//
//  Created by xiaomage on 15/6/2.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>

int main() {
    /*
     printf(" *** ***\n");
     printf("*********\n");
     printf(" *******\n");
     printf("  *****\n");
     printf("    **\n");
     */
    
    // 千万不要这么写
     printf(" *** ***\n*********\n *******\n  *****\n    **\n");
    return 0;
}
