//
//  lisi.h
//  day05
//
//  Created by xiaomage on 15/6/7.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

// 注意: .h是专门用来被拷贝的, 不会参与编译

#ifndef day05_lisi_h
#define day05_lisi_h
// 计算两个用户和
int sum(int v1, int v2);
// 计算两个用户的平均值
int average(int v1, int v2);
// 计算两个用户一年的费用
int test(int v1, int v2);
// 获取电量
int new1(int v1);
#endif
