//
//  main.c
//  递归练习2
//
//  Created by xiaomage on 15/6/7.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // 用递归法求N的阶乘
    /*
     4! = 4 * 3 * 2 * 1
     4! == 4 * 3!               3! == 3 * 2 * 1
     4! == 4 * 3 * 2!           2! == 2 * 1
     4! == 4 * 3 * 2 * 1!       1! = 1
     
     
     4! == 4 * 3 * 2 *1
     4! == 4 * 3!
     3! == 3 * 2!
     2! == 2 * 1!
     1! == 1
     
     n!= n * (n - 1)!;
     */
    int a = 3;
    int result = factorial(a);
    printf("result = %i\n", result);
    
    return 0;
}
int factorial(int n)// 3  2  1
{
    // 结束条件
    if (n == 1) {
        return 1;
    }else
    {
//      return 3 * factorial(3 - 1); == return 3 * 2
//      return 2 * factorial(2 - 1); == return 2 * 1;
        
        return n * factorial(n - 1);
    }
}
