//
//  main.c
//  递归练习3
//
//  Created by xiaomage on 15/6/7.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h> // 告诉编译器printf函数的格式, 声明printf函数

int main(int argc, const char * argv[]) {
    /*
     有5个人坐在一起,问第5个人多少岁?他说比第4个人大两岁。问 第4个人岁数,他说比第3个人大两岁。问第3个人,又说比第2个 人大两岁。问第2个人,说比第1个人大两岁。最后问第1个人, 他说是10岁。请问第5个人多大?
     
     第一个人得岁数 == 10
     第二个人得岁数 == 第一个人 + 2  // 12
     第三个人得岁数 == 第二个人 + 2  // 14
     第四个人得岁数 == 第三个人 + 2  // 16
     第五个人得岁数 == 第四个人 + 2  // 18
     
     一致第一个人得年龄, 和每个人之间的年龄差, 求第n个人的年龄
     age(1) == 10
     age(2) == age(1) + 2;
     age(3) == age(2) + 2;
     age(4) == age(3) + 2;
     age(5) == age(4) + 2;
     
     age(n) = age(n - 1) + 2;
     
     */
    
    int result = age(3);
    printf("result = %i\n", result);
    return 0;
}

int age(int n) // 3  2  1
{
   // 定义结束条件
    if (n == 1) {
        return 10;
    }else
    {
//      return 14;
//      return 12;
        
        return age(n - 1) + 2;
    }
}
