//
//  abc.h
//  Test
//
//  Created by xiaomage on 15/6/15.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#ifndef __Test__abc__
#define __Test__abc__

#include <stdio.h>

#endif /* defined(__Test__abc__) */
