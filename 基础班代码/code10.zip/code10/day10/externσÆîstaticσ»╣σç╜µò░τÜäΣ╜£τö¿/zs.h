//
//  zs.h
//  day10
//
//  Created by xiaomage on 15/6/15.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

//void test();
extern void test();

// 在.h中声明一个内部函数没有任何意义
//static void demo();