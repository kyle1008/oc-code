//
//  ls.h
//  day10
//
//  Created by xiaomage on 15/6/15.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//


// 减法运算
// v1, v2是需要参与运算的数据
int minus(int v1, int v2);

//#include "zs.h"

//int sum(int v1, int v2);