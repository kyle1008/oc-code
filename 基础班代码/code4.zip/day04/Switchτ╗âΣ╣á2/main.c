//
//  main.c
//  Switch练习2
//
//  Created by xiaomage on 15/6/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // 1.从键盘输入一个月份,输出对应季节 12~2 冬季 3~5 春季 6~ 8 夏季 9~11 秋季(用switch)
    /*
    printf("请输入一个1~12的月份, 以回车结束\n");
    int number = -1;
    scanf("%i", &number);
    switch (number) {
        case 12:
        case 1:
        case 2:
            printf("冬季");
            break;
        case 3:
        case 4:
        case 5:
            printf("春季");
            break;
        case 6:
        case 7:
        case 8:
            printf("夏季");
            break;
        case 9:
        case 10:
        case 11:
            printf("秋季");
            break;
        default:
            printf("USB\n");
            break;
    }
     
     */
    
    /*************************华丽的分割线*******************************/
    
    // 2.做一个计算器
    // 1.提示用户输入一个值
    printf("请输入第一个数\n");
    // 2.定义变量接收用户输入的值
    int number1 = -1;
    // 3.接收用户输入的值
    scanf("%i", &number1);// 10 \n
    
    char temp;
    scanf("%c", &temp);
//    getchar(); // 专门用来获取字符, 会从输入缓冲区中获取字符
    
    // 4.提示用户输入一个操作符号
    printf("请输入你要进行的运算符 + - * / \n");
    // 5.定义变量接收用户输入的操作符号
    char op;
    // 6.接收用户输入的操作符号
    scanf("%c", &op); // 会有问题
    
    // 7.提示用户再输入一个值
    printf("请输入第二个数\n");
    // 8.定义变量接收用户输入的值
    int number2 = -1;
    // 9.接收用户输入的值
    scanf("%i", &number2);
    
    // 10.根据用户的输入计算结果
    // 10.1判断用户输入的到底是什么操作符, 然后进行对应的计算
    int result = -1;
    switch (op) {
        case '+':
            result = number1 + number2;
            break;
        case '-':
            result = number1 - number2;
            break;
        case '*':
            result = number1 * number2;
            break;
        case '/':
            result = number1 / number2;
            break;
            
        default:
            
            break;
    }
    // 11.输出结果
    printf("result = %i\n", result);
    return 0;
}
