//
//  main.c
//  while练习1
//
//  Created by xiaomage on 15/6/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // 1.提示用户输入一个正整数n， 计算1 + 2 + 3 + ...n的和
    // 1.写代码之前应该先分析需求, 分析完需求再开始写代码
    // 2.一般情况下, 在做企业级开发时, 不会直接实现复杂的功能, 而且先实现一个简化的功能
    /*
       1 + 2 + 3 + 4 + 5
   0 + 1
(0 + 1)1 + 2
    (1 + 2)3 + 3
        (3 + 3)6 + 4
            (6 + 4)10 + 5
     规律 : 每一次都是用上一次的和加上一个数, 而且加上的这个数是一个递增的数
     */
    /*
    // 1.定义变量保存上一次的和
    int sum = 0;
    // 2.定义变量保存递增的数
    int count = 1;
     */
    /*
    // 3.计算
    //    0 + 1
    sum = sum + count;
    count++;
    //     1 +  2
    sum = sum + count;
    count++;
    //      3 + 3
    sum = sum + count;
    count++;
    //      6 + 4
    sum = sum + count;
    count++;
    //      10 + 5
    sum = sum + count;
    count++;
     */
    /*
    // 1.先写一个while
    // 2.找到需要循环执行的代码
    // 3.确定约束条件(结束条件)
    while (count <= 5) {
        printf("%i + %i\n", sum , count);
        sum = sum + count;
        count++;
    }
    
    printf("sum = %i\n", sum);
     */
    /*
    // 1.提示用户输入一个整数
    printf("请输入一个整数\n");
    // 2.定义变量保存用户输入的整数
    int number = -1;
    // 3.接收用户输入的整数
    scanf("%i", &number);
     */
    
    // 4.安全校验
    /*
    if (number <= 0) {
//        return 0; // 结束函数
//        break; // 注意: break只能用在switch和循环结构中, 离开这两个东西没有任何效果
    }
     */
    // 2.定义变量保存用户输入的整数
    int number = -1;
    while (number <= 0) {
        // 1.提示用户输入一个整数
        printf("请输入一个整数\n");
        
        // 3.接收用户输入的整数
        scanf("%i", &number);// -5 -10 5
    }
    
    // 4.根据用户输入的整数计算结果
    // 1 + 2 + 3 +.. +n, 规律, 用上一次的和加上一个递增的数
    // 1.先写一个while
    // 2.找到需要循环执行的代码
    // 3.确定约束条件(结束条件)
    int sum = 0;
    int count = 1;
    while (count <= number) {
//        int sum = 0; // 注意, 不能写到这个地方, 因为写到这里是一个局部变量, 作用域是从定义的这一行开始, 一直到循环体结束, 每次进来都会重新定义一个
//        int count = 1;
        
        printf("%i + %i\n", sum , count);
        // 思想: 累加思想, 通过循环来进行累加
        sum = sum + count;
        count++;
    }
    printf("sum = %i\n", sum);
    
    
    printf("other");
    return 0;
}
