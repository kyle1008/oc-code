//
//  main.c
//  99乘法表
//
//  Created by xiaomage on 15/6/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    
    /*
     1 * 1 = 1
     1 * 2 = 2 2 * 2 = 4
     */
    for (int i = 1; i <= 6; i++) {
        for (int j = 1; j <= i; j++) {
            // 1 * 1 = 1
            // 1 * 2 = 2 2 * 2 = 4
            printf("%i * %i = %i\t", j, i, j * i);
        }
        printf("\n");
    }
    return 0;
}
