//
//  main.c
//  Switch练习
//
//  Created by xiaomage on 15/6/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
   
    // 2.要求用户输入一个数, 如果用户输入的数大于100, 那么就输出牛逼
    // 1.提示用户输入一个整数
    printf("请输入一个整数, 以回车结束\n");
    // 2.定义变量保持用户输入的分数
    int number = -1;
    // 3.接收用户输入的值
    scanf("%i", &number);
    // 4.根据用户输入的值输出结果
    /*
    if (number > 100) {
        printf("NX");
    }
     */
    /*
    switch (number) {
        case 101:
            printf("NX");
            break;
        default:
            break;
    }
     */
    
    /*************************华丽的分割线*******************************/
    
    /*
     什么时候用switch, 什么时候用if
     在开发中一般情况下用if, if比较灵活
     如果说是对一些固定的值进行判断, 并且这些值得数量不多的情况, 可以使用switch
     从理论上来说, switch的性能效率比if高
     */
    return 0;
}

void test()
{
    /*
     1.要求用户输入一个分数，根据输入的分数输出对应的等级
     A 90～100 // 90/10 = 9 99/10 = 9 98/10 = 9   9|10 == A
     B 80～89 // 8
     C 70～79 // 7
     D 60～69 // 6
     E 0～59 //
     */
    // 1.第一种实现方式 if
    // 1.提示用户输入一个分数
    printf("请输入一个0~100的分数, 以回车结束\n");
    // 2.定义变量保持用户输入的分数
    int score = -1;
    // 3.接收用户输入的值
    scanf("%i", &score);
    // 4.根据用户输入的值输出对应的结果
    /*
     if (score >= 90 && score <= 100) {
     printf("A\n");
     }else if (score >= 80 && score <= 89)
     {
     printf("B\n");
     }else if (score >= 70 && score <= 79)
     {
     printf("C\n");
     }else if (score >= 60 && score <= 69)
     {
     printf("D\n");
     }else
     {
     printf("E\n");
     }
     */
    
    /*************************华丽的分割线*******************************/
    
    /*
     if (score < 0 || score > 100) {
     printf("youtube\n");
     }else if (score >= 90 && score <= 100) { // 70
     printf("A\n");
     }else if (score >= 80)
     {
     printf("B\n");
     }else if (score >= 70)
     {
     printf("C\n");
     }else if (score >= 60)
     {
     printf("D\n");
     }else
     {
     printf("E\n");
     }
     */
    
    /*************************华丽的分割线*******************************/
    
    /*
     // 2.第二种实现方式 switch
     switch (score/10) {
     case 10:
     //            printf("A\n");
     //            break;
     case 9:
     printf("A\n");
     break;
     case 8:
     printf("B\n");
     break;
     case 7:
     printf("C\n");
     break;
     case 6:
     printf("D\n");
     default:
     printf("E\n");
     break;
     }
     */
}
